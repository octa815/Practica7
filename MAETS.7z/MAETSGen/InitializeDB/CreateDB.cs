
/*PROTECTED REGION ID(CreateDB_imports) ENABLED START*/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using MAETSGen.ApplicationCore.EN.MAETS;
using MAETSGen.ApplicationCore.CEN.MAETS;
using MAETSGen.Infraestructure.Repository.MAETS;
using MAETSGen.Infraestructure.CP;
using MAETSGen.ApplicationCore.Exceptions;

using MAETSGen.ApplicationCore.CP.MAETS;
using MAETSGen.Infraestructure.Repository;

/*PROTECTED REGION END*/
namespace InitializeDB
{
public class CreateDB
{
public static void Create (string databaseArg, string userArg, string passArg)
{
        String database = databaseArg;
        String user = userArg;
        String pass = passArg;

        // Conex DB
        SqlConnection cnn = new SqlConnection (@"Server=(local)\sqlexpress; database=master; integrated security=yes");

        // Order T-SQL create user
        String createUser = @"IF NOT EXISTS(SELECT name FROM master.dbo.syslogins WHERE name = '" + user + @"')
            BEGIN
                CREATE LOGIN ["                                                                                                                                     + user + @"] WITH PASSWORD=N'" + pass + @"', DEFAULT_DATABASE=[master], CHECK_EXPIRATION=OFF, CHECK_POLICY=OFF
            END"                                                                                                                                                                                                                                                                                    ;

        //Order delete user if exist
        String deleteDataBase = @"if exists(select * from sys.databases where name = '" + database + "') DROP DATABASE [" + database + "]";
        //Order create databas
        string createBD = "CREATE DATABASE " + database;
        //Order associate user with database
        String associatedUser = @"USE [" + database + "];CREATE USER [" + user + "] FOR LOGIN [" + user + "];USE [" + database + "];EXEC sp_addrolemember N'db_owner', N'" + user + "'";
        SqlCommand cmd = null;

        try
        {
                // Open conex
                cnn.Open ();

                //Create user in SQLSERVER
                cmd = new SqlCommand (createUser, cnn);
                cmd.ExecuteNonQuery ();

                //DELETE database if exist
                cmd = new SqlCommand (deleteDataBase, cnn);
                cmd.ExecuteNonQuery ();

                //CREATE DB
                cmd = new SqlCommand (createBD, cnn);
                cmd.ExecuteNonQuery ();

                //Associate user with db
                cmd = new SqlCommand (associatedUser, cnn);
                cmd.ExecuteNonQuery ();

                System.Console.WriteLine ("DataBase create sucessfully..");
        }
        catch (Exception)
        {
                throw;
        }
        finally
        {
                if (cnn.State == ConnectionState.Open) {
                        cnn.Close ();
                }
        }
}

public static void InitializeData ()
{
        try
        {
                // Initialising  CENs
                ClienteRepository clienterepository = new ClienteRepository ();
                ClienteCEN clientecen = new ClienteCEN (clienterepository);
                AdministradorRepository administradorrepository = new AdministradorRepository ();
                AdministradorCEN administradorcen = new AdministradorCEN (administradorrepository);
                JuegoRepository juegorepository = new JuegoRepository ();
                JuegoCEN juegocen = new JuegoCEN (juegorepository);
                CestaRepository cestarepository = new CestaRepository ();
                CestaCEN cestacen = new CestaCEN (cestarepository);
                BibliotecaRepository bibliotecarepository = new BibliotecaRepository ();
                BibliotecaCEN bibliotecacen = new BibliotecaCEN (bibliotecarepository);
                LogroRepository logrorepository = new LogroRepository ();
                LogroCEN logrocen = new LogroCEN (logrorepository);
                LineaCestaRepository lineacestarepository = new LineaCestaRepository ();
                LineaCestaCEN lineacestacen = new LineaCestaCEN (lineacestarepository);
                MAETSRepository maetsrepository = new MAETSRepository ();
                MAETSCEN maetscen = new MAETSCEN (maetsrepository);
                ConsultaRepository consultarepository = new ConsultaRepository ();
                ConsultaCEN consultacen = new ConsultaCEN (consultarepository);
                ComentariosRepository comentariosrepository = new ComentariosRepository ();
                ComentariosCEN comentarioscen = new ComentariosCEN (comentariosrepository);
                CategoriasRepository categoriasrepository = new CategoriasRepository ();
                CategoriasCEN categoriascen = new CategoriasCEN (categoriasrepository);
                UsuarioRepository usuariorepository = new UsuarioRepository ();
                UsuarioCEN usuariocen = new UsuarioCEN (usuariorepository);
                DistribuidoraRepository distribuidorarepository = new DistribuidoraRepository ();
                DistribuidoraCEN distribuidoracen = new DistribuidoraCEN (distribuidorarepository);
                CopiaRepository copiarepository = new CopiaRepository ();
                CopiaCEN copiacen = new CopiaCEN (copiarepository);



                /*PROTECTED REGION ID(initializeDataMethod) ENABLED START*/

                string usu1 = usuariocen.Nuevo ("12345678A", "5678", DateTime.Today, "Juan", "juan@gmail.com");
                string usu2 = usuariocen.Nuevo ("87654321B", "9012", DateTime.Today, "Ana", "ana@gmail.com");
                string usu3 = usuariocen.Nuevo ("23456789C", "3456", DateTime.Today, "Carlos", "carlos@gmail.com");
                string usu4 = usuariocen.Nuevo ("98765432D", "7890", DateTime.Today, "Laura", "laura@gmail.com");
                string usu5 = usuariocen.Nuevo ("34567890E", "2345", DateTime.Today, "Roberto", "roberto@gmail.com");

                Console.WriteLine ("_______________________________________________________________________________");
                Console.WriteLine ("Usuarios creados con exito");
                Console.WriteLine ("_______________________________________________________________________________");


                int logro1 = logrocen.Nuevo ("10hjugadas", "Juega 10 horas");
                int logro2 = logrocen.Nuevo ("500pts", "Alcanza 500 puntos");
                int logro3 = logrocen.Nuevo ("25wins", "Gana 25 partidas");
                int logro4 = logrocen.Nuevo ("teamplayer", "Sé un jugador en equipo");
                int logro5 = logrocen.Nuevo ("100kills", "Consigue 100 eliminaciones");

                Console.WriteLine ("_______________________________________________________________________________");
                Console.WriteLine ("Logro creado con exito");
                Console.WriteLine ("_______________________________________________________________________________");


                string admin1 = administradorcen.Nuevo ("88887777C", "456123", DateTime.Today);
                string admin2 = administradorcen.Nuevo ("99998888D", "789234", DateTime.Today);
                string admin3 = administradorcen.Nuevo ("10102345E", "012567", DateTime.Today);
                string admin4 = administradorcen.Nuevo ("12123456F", "345890", DateTime.Today);
                string admin5 = administradorcen.Nuevo ("13124567G", "678901", DateTime.Today);

                Console.WriteLine ("_______________________________________________________________________________");
                Console.WriteLine ("admin creado con exito");
                Console.WriteLine ("_______________________________________________________________________________");


                string clien1 = clientecen.Nuevo ("11223344A", "123456", DateTime.Today);
                string clien2 = clientecen.Nuevo ("22334455B", "789012", DateTime.Today);
                string clien3 = clientecen.Nuevo ("33445566C", "345678", DateTime.Today);
                string clien4 = clientecen.Nuevo ("44556677D", "901234", DateTime.Today);
                string clien5 = clientecen.Nuevo ("55667788E", "567890", DateTime.Today);

                Console.WriteLine ("_______________________________________________________________________________");
                Console.WriteLine ("Cliente creado con exito");
                Console.WriteLine ("_______________________________________________________________________________");



                int dist1 = distribuidoracen.Nuevo ("Sony");
                int dist2 = distribuidoracen.Nuevo ("Microsoft");
                int dist3 = distribuidoracen.Nuevo ("Ubisoft");
                int dist4 = distribuidoracen.Nuevo ("Electronic Arts");
                int dist5 = distribuidoracen.Nuevo ("Activision");

                Console.WriteLine ("_______________________________________________________________________________");
                Console.WriteLine ("Distribuidora creada con exito");
                Console.WriteLine ("_______________________________________________________________________________");


                string cate1 = categoriascen.Nuevo ("Terror");
                string cate2 = categoriascen.Nuevo ("Aventura");
                string cate3 = categoriascen.Nuevo ("Deportes");
                string cate4 = categoriascen.Nuevo ("Estrategia");
                string cate5 = categoriascen.Nuevo ("RPG");

                Console.WriteLine ("_______________________________________________________________________________");
                Console.WriteLine ("Categor�a creada con exito");
                Console.WriteLine ("_______________________________________________________________________________");


                int maets = maetscen.Nuevo ();
                Console.WriteLine ("_______________________________________________________________________________");
                Console.WriteLine ("MAETS creada con exito");
                Console.WriteLine ("_______________________________________________________________________________");


                string juego1 = juegocen.Nuevo ("Mario", DateTime.Today, 4, 2, "tenerpc", maets, cate1, dist1);
                string juego2 = juegocen.Nuevo ("Zelda", DateTime.Today, 3, 1, "tenerpc", maets, cate2, dist2);
                string juego3 = juegocen.Nuevo ("FIFA", DateTime.Today, 2, 3, "tenerpc", maets, cate3, dist3);
                string juego4 = juegocen.Nuevo ("Civilization", DateTime.Today, 5, 2, "tenerpc", maets, cate4, dist4);
                string juego5 = juegocen.Nuevo ("The Witcher", DateTime.Today, 5, 3, "tenerpc", maets, cate5, dist5);

                Console.WriteLine ("_______________________________________________________________________________");
                Console.WriteLine ("Juego creado con exito");
                Console.WriteLine ("_______________________________________________________________________________");



                int consulta1 = consultacen.Nuevo ("Consulta 1", 1, admin1, usu1);
                int consulta2 = consultacen.Nuevo ("Consulta 2", 2, admin2, usu2);
                int consulta3 = consultacen.Nuevo ("Consulta 3", 3, admin3, usu3);
                int consulta4 = consultacen.Nuevo ("Consulta 4", 4, admin4, usu4);
                int consulta5 = consultacen.Nuevo ("Consulta 5", 5, admin5, usu5);

                Console.WriteLine ("_______________________________________________________________________________");
                Console.WriteLine ("consulta creada con exito");
                Console.WriteLine ("_______________________________________________________________________________");

                int cesta1 = cestacen.Nuevo (clien1, DateTime.Today, true, MAETSGen.ApplicationCore.Enumerated.MAETS.Tipo_PlanEnum.basico);
                int cesta2 = cestacen.Nuevo (clien2, DateTime.Today, true, MAETSGen.ApplicationCore.Enumerated.MAETS.Tipo_PlanEnum.basico);
                int cesta3 = cestacen.Nuevo (clien3, DateTime.Today, false, MAETSGen.ApplicationCore.Enumerated.MAETS.Tipo_PlanEnum.basico);
                int cesta4 = cestacen.Nuevo (clien4, DateTime.Today, true, MAETSGen.ApplicationCore.Enumerated.MAETS.Tipo_PlanEnum.basico);
                int cesta5 = cestacen.Nuevo (clien5, DateTime.Today, false, MAETSGen.ApplicationCore.Enumerated.MAETS.Tipo_PlanEnum.basico);

                Console.WriteLine ("_______________________________________________________________________________");
                Console.WriteLine ("cesta creada con exito");
                Console.WriteLine ("_______________________________________________________________________________");

                int l_cesta1 = lineacestacen.Nuevo (cesta1, juego1);
                int l_cesta2 = lineacestacen.Nuevo (cesta2, juego1);
                int l_cesta3 = lineacestacen.Nuevo (cesta3, juego3);
                int l_cesta4 = lineacestacen.Nuevo (cesta1, juego4);
                int l_cesta5 = lineacestacen.Nuevo (cesta4, juego5);

                Console.WriteLine ("_______________________________________________________________________________");
                Console.WriteLine ("lineas de cesta creada con exito");
                Console.WriteLine ("_______________________________________________________________________________");

                int comentario1 = comentarioscen.Nuevo (clien1, juego1, "Excelente juego");
                int comentario2 = comentarioscen.Nuevo (clien2, juego2, "Me encanta este juego");
                int comentario3 = comentarioscen.Nuevo (clien3, juego3, "No puedo dejar de jugarlo");
                int comentario4 = comentarioscen.Nuevo (clien4, juego4, "Buen juego, pero necesita mejoras");
                int comentario5 = comentarioscen.Nuevo (clien5, juego5, "No lo recomendaría, hay mejores opciones");

                Console.WriteLine ("_______________________________________________________________________________");
                Console.WriteLine ("comentario creado con exito");
                Console.WriteLine ("_______________________________________________________________________________");

                int biblioteca1 = bibliotecacen.Nuevo (clien1);
                int biblioteca2 = bibliotecacen.Nuevo (clien2);
                int biblioteca3 = bibliotecacen.Nuevo (clien3);
                int biblioteca4 = bibliotecacen.Nuevo (clien4);
                int biblioteca5 = bibliotecacen.Nuevo (clien5);

                Console.WriteLine ("_______________________________________________________________________________");
                Console.WriteLine ("bilioteca creada con exito");
                Console.WriteLine ("_______________________________________________________________________________");


                int copia1 = copiacen.Nuevo (biblioteca1, juego1, MAETSGen.ApplicationCore.Enumerated.MAETS.Estado_juegoEnum.en_curso);
                int copia2 = copiacen.Nuevo (biblioteca2, juego2, MAETSGen.ApplicationCore.Enumerated.MAETS.Estado_juegoEnum.en_curso);
                int copia2_2 = copiacen.Nuevo (biblioteca1, juego2, MAETSGen.ApplicationCore.Enumerated.MAETS.Estado_juegoEnum.en_curso);
                int copia3 = copiacen.Nuevo (biblioteca3, juego3, MAETSGen.ApplicationCore.Enumerated.MAETS.Estado_juegoEnum.en_curso);
                int copia4 = copiacen.Nuevo (biblioteca4, juego4, MAETSGen.ApplicationCore.Enumerated.MAETS.Estado_juegoEnum.en_curso);
                int copia5 = copiacen.Nuevo (biblioteca5, juego5, MAETSGen.ApplicationCore.Enumerated.MAETS.Estado_juegoEnum.en_curso);


                //CONSULTAS
                //READ FILTER 1
                IList <CestaEN> cestaporjuego = cestacen.DameCestaJuego (juego1);
                Console.WriteLine ("consultamos las cestas que tienen el juego: " + juego1);
                foreach (CestaEN cesta in cestaporjuego) {
                        Console.WriteLine ("_______________________________________________________________________________");
                        Console.WriteLine ("El juego esta en la cesta: " + cesta.Id_pedido);
                        Console.WriteLine ("_______________________________________________________________________________");
                }
                //READ FILTER 2
                IList<ClienteEN> c_comenta_juego = clientecen.DameClientesJuego (juego1);
                Console.WriteLine ("consultamos los clientes que han comentado el juego: " + juego1);
                foreach (ClienteEN cliente in c_comenta_juego) {
                        Console.WriteLine ("_______________________________________________________________________________");
                        Console.WriteLine ("El juego ha sido comentado por: " + cliente.Dni);
                        Console.WriteLine ("_______________________________________________________________________________");
                }

                //READ FILTER 3
                IList<JuegoEN> juegoporcat = juegocen.DameJuegoporCat (cate1);
                Console.WriteLine ("consultamos los juegos que tienen la categoria: " + cate1);
                foreach (JuegoEN game in juegoporcat) {
                        Console.WriteLine ("_______________________________________________________________________________");
                        Console.WriteLine ("La categoria tiene al juego: " + game.Nombre);
                        Console.WriteLine ("_______________________________________________________________________________");
                }

                //READ FILTER 4
                IList<AdministradorEN> adminausu = administradorcen.DameAdminporUsu (usu1);
                Console.WriteLine ("consultamos los administradores que han atendido al usuario: " + usu1);
                foreach (AdministradorEN admin in adminausu) {
                        Console.WriteLine ("_______________________________________________________________________________");
                        Console.WriteLine ("El usuario ha sido atendido por: " + admin.Dni);
                        Console.WriteLine ("_______________________________________________________________________________");
                }


                //READ FILTER 5

                IList<CopiaEN> estadojuego = copiacen.DameEstadoJuego (MAETSGen.ApplicationCore.Enumerated.MAETS.Estado_juegoEnum.en_curso);
                Console.WriteLine ("consultamos los juegos que tienen el estado de: " + MAETSGen.ApplicationCore.Enumerated.MAETS.Estado_juegoEnum.en_curso);
                foreach (CopiaEN cop  in estadojuego) {
                        Console.WriteLine ("______________________________________________________________________________________________________");
                        Console.WriteLine ("Tiene el estado el juego: " + cop.Juego.Nombre + " de la copia número: " + cop.Estado);
                        Console.WriteLine ("______________________________________________________________________________________________________");
                } //No se pq no funciona parece que esta bien

                //READ FILTER 6

                IList<CestaEN> plancesta = cestacen.DameTipoPlan (MAETSGen.ApplicationCore.Enumerated.MAETS.Tipo_PlanEnum.basico);
                Console.WriteLine ("consultamos los cestas que tienen el plan: " + MAETSGen.ApplicationCore.Enumerated.MAETS.Tipo_PlanEnum.basico);
                foreach (CestaEN cesta in plancesta) {
                        Console.WriteLine ("_______________________________________________________________________________");
                        Console.WriteLine ("Tiene ese plan la cesta: " + cesta.Id_pedido);
                        Console.WriteLine ("_______________________________________________________________________________");
                }

                //READ FILTER 7

                IList<UsuarioEN> usuemail = usuariocen.DameEmail (usu1);
                Console.WriteLine ("Consultamos el email de: " + usu1);
                foreach (UsuarioEN usu in usuemail) {
                        Console.WriteLine ("_______________________________________________________________________________");
                        Console.WriteLine ("El email de " + usu1 + " es: " + usu.Email);
                        Console.WriteLine ("_______________________________________________________________________________");
                }

                //READ FILTER 8

                IList<ClienteEN> clientepass = clientecen.DamePassword (clien1);
                Console.WriteLine ("Consultamos la contraseña de: " + clien1);
                foreach (ClienteEN cli in clientepass) {
                        Console.WriteLine ("_______________________________________________________________________________");
                        Console.WriteLine ("La contaseña de " + clien1 + " es: " + cli.Pass);
                        Console.WriteLine ("_______________________________________________________________________________");
                }
                //READ FILTER 9
                IList<CopiaEN> numcopias = copiacen.DameCopias (juego2);
                Console.WriteLine ("Consultamos cuantas copias hay de: " + juego2);
                int cuantas = 0;
                foreach (CopiaEN cop in numcopias) {
                        Console.WriteLine ("_______________________________________________________________________________");
                        Console.WriteLine ("Existe la copia: " + cop.Num_copia);
                        Console.WriteLine ("_______________________________________________________________________________");
                        cuantas++;
                }
                Console.WriteLine ("_______________________________________________________________________________");
                Console.WriteLine ("Total de copias de " + juego2 + ": " + cuantas);
                Console.WriteLine ("_______________________________________________________________________________");






                //CUSTOMS

                copiacen.CambiarEstado (copia1, MAETSGen.ApplicationCore.Enumerated.MAETS.Estado_juegoEnum.agotado);
                Console.WriteLine ("_______________________________________________________________________________");
                Console.WriteLine ("El juego ha cambiado su estado a agotado. ");
                Console.WriteLine ("_______________________________________________________________________________");
                copiacen.CambiarEstado (copia1, MAETSGen.ApplicationCore.Enumerated.MAETS.Estado_juegoEnum.agotado);
                Console.WriteLine ("_______________________________________________________________________________");
                Console.WriteLine ("El juego no ha cambiado su estado porque es el mismo");
                Console.WriteLine ("_______________________________________________________________________________");
                copiacen.CambiarEstado (copia1, MAETSGen.ApplicationCore.Enumerated.MAETS.Estado_juegoEnum.adquirido);
                Console.WriteLine ("_______________________________________________________________________________");
                Console.WriteLine ("El juego ha sido adquirido");
                Console.WriteLine ("_______________________________________________________________________________");
                copiacen.CambiarEstado (copia1, MAETSGen.ApplicationCore.Enumerated.MAETS.Estado_juegoEnum.agotado);
                Console.WriteLine ("_______________________________________________________________________________");
                Console.WriteLine ("El juego ya ha sido adquirido");
                Console.WriteLine ("_______________________________________________________________________________");

                IList<CopiaEN> estadojuegoagain = copiacen.DameEstadoJuego (MAETSGen.ApplicationCore.Enumerated.MAETS.Estado_juegoEnum.adquirido);
                Console.WriteLine ("consultamos los juegos que tienen el estado de: " + MAETSGen.ApplicationCore.Enumerated.MAETS.Estado_juegoEnum.adquirido);
                foreach (CopiaEN cop in estadojuego) {
                        Console.WriteLine ("______________________________________________________________________________________________________");
                        Console.WriteLine ("Tiene el estado el juego: " + cop.Juego.Nombre + " de la copia número: " + cop.Estado);
                        Console.WriteLine ("______________________________________________________________________________________________________");
                }


                cestacen.CambiarPlan (cesta1, MAETSGen.ApplicationCore.Enumerated.MAETS.Tipo_PlanEnum.basico);
                Console.WriteLine ("_______________________________________________________________________________");
                Console.WriteLine ("El plan no puede cambiar porque es el mismo");
                Console.WriteLine ("_______________________________________________________________________________");
                cestacen.CambiarPlan (cesta1, MAETSGen.ApplicationCore.Enumerated.MAETS.Tipo_PlanEnum.personalizado);
                Console.WriteLine ("_______________________________________________________________________________");
                Console.WriteLine ("El plan ha cambiado a personalizado");
                Console.WriteLine ("_______________________________________________________________________________");
                cestacen.CambiarPlan (cesta1, MAETSGen.ApplicationCore.Enumerated.MAETS.Tipo_PlanEnum.adquisicion);
                Console.WriteLine ("_______________________________________________________________________________");
                Console.WriteLine ("El plan ha cambiado a adqusicion");
                Console.WriteLine ("_______________________________________________________________________________");

                IList<CestaEN> plancestaagain = cestacen.DameTipoPlan (MAETSGen.ApplicationCore.Enumerated.MAETS.Tipo_PlanEnum.basico);
                Console.WriteLine ("______________________________________________________________________________________________________________");
                Console.WriteLine ("consultamos los cestas que tienen el plan: " + MAETSGen.ApplicationCore.Enumerated.MAETS.Tipo_PlanEnum.basico);
                Console.WriteLine ("______________________________________________________________________________________________________________");
                foreach (CestaEN cesta in plancestaagain) {
                        Console.WriteLine ("_______________________________________________________________________________");
                        Console.WriteLine ("Tiene el estado el juego: " + cesta.Id_pedido);
                        Console.WriteLine ("_______________________________________________________________________________");
                }

                cestacen.CambiarPlan (cesta1, MAETSGen.ApplicationCore.Enumerated.MAETS.Tipo_PlanEnum.basico);
                Console.WriteLine ("_______________________________________________________________________________");
                Console.WriteLine ("El plan ha cambiado a basico");
                Console.WriteLine ("_______________________________________________________________________________");




                usuariocen.CambiarCorreo (usu1, "5678", "juan@gmail.com");
                Console.WriteLine ("Correo no cambiado");
                usuariocen.CambiarCorreo (usu1, "1278", "dsm@gmail.com");
                Console.WriteLine ("Correo no cambiado, contraseñas no coinciden");
                usuariocen.CambiarCorreo (usu1, "5678", "arribaespana@gmail.com");
                Console.WriteLine ("Correo cambiado");

                IList<UsuarioEN> usuemailagain = usuariocen.DameEmail (usu1);
                Console.WriteLine ("_______________________________________________________________________________");
                Console.WriteLine ("Consultamos el email de: " + usu1);
                Console.WriteLine ("_______________________________________________________________________________");
                foreach (UsuarioEN usu in usuemailagain) {
                        Console.WriteLine ("_______________________________________________________________________________");
                        Console.WriteLine ("El email de " + usu1 + " es: " + usu.Email);
                        Console.WriteLine ("_______________________________________________________________________________");
                }



                clientecen.CambiarPass (clien1, "5478", "3321");
                Console.WriteLine ("Contraseña no cambiada");
                clientecen.CambiarPass (clien1, "123456", "pepe27");
                Console.WriteLine ("Contraseña cambiada");

                IList<ClienteEN> clientepassagain = clientecen.DamePassword (clien1);
                Console.WriteLine ("_______________________________________________________________________________");
                Console.WriteLine ("Consultamos la contraseña de: " + clien1);
                Console.WriteLine ("_______________________________________________________________________________");
                foreach (ClienteEN cli in clientepassagain) {
                        Console.WriteLine ("_______________________________________________________________________________");
                        Console.WriteLine ("La contaseña de " + clien1 + " es: " + cli.Pass);
                        Console.WriteLine ("_______________________________________________________________________________");
                }




                /*PROTECTED REGION END*/
        }
        catch (Exception ex)
        {
                System.Console.WriteLine (ex.InnerException);
                throw;
        }
}
}
}
