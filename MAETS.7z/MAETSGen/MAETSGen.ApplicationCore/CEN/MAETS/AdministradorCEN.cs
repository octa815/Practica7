

using System;
using System.Text;
using System.Collections.Generic;

using MAETSGen.ApplicationCore.Exceptions;

using MAETSGen.ApplicationCore.EN.MAETS;
using MAETSGen.ApplicationCore.IRepository.MAETS;


namespace MAETSGen.ApplicationCore.CEN.MAETS
{
/*
 *      Definition of the class AdministradorCEN
 *
 */
public partial class AdministradorCEN
{
private IAdministradorRepository _IAdministradorRepository;

public AdministradorCEN(IAdministradorRepository _IAdministradorRepository)
{
        this._IAdministradorRepository = _IAdministradorRepository;
}

public IAdministradorRepository get_IAdministradorRepository ()
{
        return this._IAdministradorRepository;
}

public string Nuevo (string p_dni, string p_pass, Nullable<DateTime> p_fechareg)
{
        AdministradorEN administradorEN = null;
        string oid;

        //Initialized AdministradorEN
        administradorEN = new AdministradorEN ();
        administradorEN.Dni = p_dni;

        administradorEN.Pass = p_pass;

        administradorEN.Fechareg = p_fechareg;



        oid = _IAdministradorRepository.Nuevo (administradorEN);
        return oid;
}

public System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.AdministradorEN> DameAdminporUsu (string n_usu)
{
        return _IAdministradorRepository.DameAdminporUsu (n_usu);
}
}
}
