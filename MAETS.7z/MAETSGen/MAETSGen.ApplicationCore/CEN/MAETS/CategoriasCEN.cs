

using System;
using System.Text;
using System.Collections.Generic;

using MAETSGen.ApplicationCore.Exceptions;

using MAETSGen.ApplicationCore.EN.MAETS;
using MAETSGen.ApplicationCore.IRepository.MAETS;


namespace MAETSGen.ApplicationCore.CEN.MAETS
{
/*
 *      Definition of the class CategoriasCEN
 *
 */
public partial class CategoriasCEN
{
private ICategoriasRepository _ICategoriasRepository;

public CategoriasCEN(ICategoriasRepository _ICategoriasRepository)
{
        this._ICategoriasRepository = _ICategoriasRepository;
}

public ICategoriasRepository get_ICategoriasRepository ()
{
        return this._ICategoriasRepository;
}

public string Nuevo (string p_cat)
{
        CategoriasEN categoriasEN = null;
        string oid;

        //Initialized CategoriasEN
        categoriasEN = new CategoriasEN ();
        categoriasEN.Cat = p_cat;



        oid = _ICategoriasRepository.Nuevo (categoriasEN);
        return oid;
}

public void Modificar (string p_Categorias_OID)
{
        CategoriasEN categoriasEN = null;

        //Initialized CategoriasEN
        categoriasEN = new CategoriasEN ();
        categoriasEN.Cat = p_Categorias_OID;
        //Call to CategoriasRepository

        _ICategoriasRepository.Modificar (categoriasEN);
}

public void Borrar (string cat
                    )
{
        _ICategoriasRepository.Borrar (cat);
}
}
}
