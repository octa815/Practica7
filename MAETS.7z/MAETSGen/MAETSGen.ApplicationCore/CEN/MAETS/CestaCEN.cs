

using System;
using System.Text;
using System.Collections.Generic;

using MAETSGen.ApplicationCore.Exceptions;

using MAETSGen.ApplicationCore.EN.MAETS;
using MAETSGen.ApplicationCore.IRepository.MAETS;


namespace MAETSGen.ApplicationCore.CEN.MAETS
{
/*
 *      Definition of the class CestaCEN
 *
 */
public partial class CestaCEN
{
private ICestaRepository _ICestaRepository;

public CestaCEN(ICestaRepository _ICestaRepository)
{
        this._ICestaRepository = _ICestaRepository;
}

public ICestaRepository get_ICestaRepository ()
{
        return this._ICestaRepository;
}

public int Nuevo (string p_Cliente, Nullable<DateTime> p_fecha_add, bool p_estado, MAETSGen.ApplicationCore.Enumerated.MAETS.Tipo_PlanEnum p_plan_alq)
{
        CestaEN cestaEN = null;
        int oid;

        //Initialized CestaEN
        cestaEN = new CestaEN ();

        if (p_Cliente != null) {
                // El argumento p_Cliente -> Property Cliente es oid = false
                // Lista de oids id_pedido
                cestaEN.Cliente = new MAETSGen.ApplicationCore.EN.MAETS.ClienteEN ();
                cestaEN.Cliente.Dni = p_Cliente;
        }

        cestaEN.Fecha_add = p_fecha_add;

        cestaEN.Estado = p_estado;

        cestaEN.Plan_alq = p_plan_alq;



        oid = _ICestaRepository.Nuevo (cestaEN);
        return oid;
}

public void Modificar (int p_Cesta_OID, Nullable<DateTime> p_fecha_add, bool p_estado, MAETSGen.ApplicationCore.Enumerated.MAETS.Tipo_PlanEnum p_plan_alq)
{
        CestaEN cestaEN = null;

        //Initialized CestaEN
        cestaEN = new CestaEN ();
        cestaEN.Id_pedido = p_Cesta_OID;
        cestaEN.Fecha_add = p_fecha_add;
        cestaEN.Estado = p_estado;
        cestaEN.Plan_alq = p_plan_alq;
        //Call to CestaRepository

        _ICestaRepository.Modificar (cestaEN);
}

public void Borrar (int id_pedido
                    )
{
        _ICestaRepository.Borrar (id_pedido);
}

public CestaEN LeeID (int id_pedido
                      )
{
        CestaEN cestaEN = null;

        cestaEN = _ICestaRepository.LeeID (id_pedido);
        return cestaEN;
}

public System.Collections.Generic.IList<CestaEN> LeeTodos (int first, int size)
{
        System.Collections.Generic.IList<CestaEN> list = null;

        list = _ICestaRepository.LeeTodos (first, size);
        return list;
}
public System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.CestaEN> DameCestaJuego (string c_juego)
{
        return _ICestaRepository.DameCestaJuego (c_juego);
}
public System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.CestaEN> DameTipoPlan (MAETSGen.ApplicationCore.Enumerated.MAETS.Tipo_PlanEnum ? plan)
{
        return _ICestaRepository.DameTipoPlan (plan);
}
}
}
