

using System;
using System.Text;
using System.Collections.Generic;

using MAETSGen.ApplicationCore.Exceptions;

using MAETSGen.ApplicationCore.EN.MAETS;
using MAETSGen.ApplicationCore.IRepository.MAETS;
using Newtonsoft.Json;


namespace MAETSGen.ApplicationCore.CEN.MAETS
{
/*
 *      Definition of the class ClienteCEN
 *
 */
public partial class ClienteCEN
{
private IClienteRepository _IClienteRepository;

public ClienteCEN(IClienteRepository _IClienteRepository)
{
        this._IClienteRepository = _IClienteRepository;
}

public IClienteRepository get_IClienteRepository ()
{
        return this._IClienteRepository;
}

public string Nuevo (string p_dni, string p_pass, Nullable<DateTime> p_fechareg)
{
        ClienteEN clienteEN = null;
        string oid;

        //Initialized ClienteEN
        clienteEN = new ClienteEN ();
        clienteEN.Dni = p_dni;

        clienteEN.Pass = p_pass;

        clienteEN.Fechareg = p_fechareg;



        oid = _IClienteRepository.Nuevo (clienteEN);
        return oid;
}

public void Modificar (string p_Cliente_OID, string p_pass, Nullable<DateTime> p_fechareg)
{
        ClienteEN clienteEN = null;

        //Initialized ClienteEN
        clienteEN = new ClienteEN ();
        clienteEN.Dni = p_Cliente_OID;
        clienteEN.Pass = p_pass;
        clienteEN.Fechareg = p_fechareg;
        //Call to ClienteRepository

        _IClienteRepository.Modificar (clienteEN);
}

public void Borrar (string dni
                    )
{
        _IClienteRepository.Borrar (dni);
}

public ClienteEN LeeID (string dni
                        )
{
        ClienteEN clienteEN = null;

        clienteEN = _IClienteRepository.LeeID (dni);
        return clienteEN;
}

public System.Collections.Generic.IList<ClienteEN> LeeTodos (int first, int size)
{
        System.Collections.Generic.IList<ClienteEN> list = null;

        list = _IClienteRepository.LeeTodos (first, size);
        return list;
}
public System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.ClienteEN> DameClientesJuego (string cc_juego)
{
        return _IClienteRepository.DameClientesJuego (cc_juego);
}
public System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.ClienteEN> DamePassword (string cliente)
{
        return _IClienteRepository.DamePassword (cliente);
}



private string Encode (string dni)
{
        var payload = new Dictionary<string, object>(){
                { "dni", dni }
        };
        string token = Jose.JWT.Encode (payload, Utils.Util.getKey (), Jose.JwsAlgorithm.HS256);

        return token;
}

public string GetToken (string dni)
{
        ClienteEN en = _IClienteRepository.ReadOIDDefault (dni);
        string token = Encode (en.Dni);

        return token;
}
public string CheckToken (string token)
{
        string result = null;

        try
        {
                string decodedToken = Utils.Util.Decode (token);



                string id = (string)ObtenerDNI (decodedToken);

                ClienteEN en = _IClienteRepository.ReadOIDDefault (id);

                if (en != null && ((string)en.Dni).Equals (ObtenerDNI (decodedToken))
                    ) {
                        result = id;
                }
                else throw new ModelException ("El token es incorrecto");
        } catch (Exception)
        {
                throw new ModelException ("El token es incorrecto");
        }

        return result;
}


public string ObtenerDNI (string decodedToken)
{
        try
        {
                Dictionary<string, object> results = JsonConvert.DeserializeObject<Dictionary<string, object> >(decodedToken);
                string dni = (string)results ["dni"];
                return dni;
        }
        catch
        {
                throw new Exception ("El token enviado no es correcto");
        }
}
}
}
