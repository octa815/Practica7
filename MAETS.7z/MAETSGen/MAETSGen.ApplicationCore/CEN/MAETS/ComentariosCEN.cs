

using System;
using System.Text;
using System.Collections.Generic;

using MAETSGen.ApplicationCore.Exceptions;

using MAETSGen.ApplicationCore.EN.MAETS;
using MAETSGen.ApplicationCore.IRepository.MAETS;


namespace MAETSGen.ApplicationCore.CEN.MAETS
{
/*
 *      Definition of the class ComentariosCEN
 *
 */
public partial class ComentariosCEN
{
private IComentariosRepository _IComentariosRepository;

public ComentariosCEN(IComentariosRepository _IComentariosRepository)
{
        this._IComentariosRepository = _IComentariosRepository;
}

public IComentariosRepository get_IComentariosRepository ()
{
        return this._IComentariosRepository;
}

public int Nuevo (string p_Cliente, string p_juego, string p_texto)
{
        ComentariosEN comentariosEN = null;
        int oid;

        //Initialized ComentariosEN
        comentariosEN = new ComentariosEN ();

        if (p_Cliente != null) {
                // El argumento p_Cliente -> Property Cliente es oid = false
                // Lista de oids id
                comentariosEN.Cliente = new MAETSGen.ApplicationCore.EN.MAETS.ClienteEN ();
                comentariosEN.Cliente.Dni = p_Cliente;
        }


        if (p_juego != null) {
                // El argumento p_juego -> Property juego es oid = false
                // Lista de oids id
                comentariosEN.Juego = new MAETSGen.ApplicationCore.EN.MAETS.JuegoEN ();
                comentariosEN.Juego.Nombre = p_juego;
        }

        comentariosEN.Texto = p_texto;



        oid = _IComentariosRepository.Nuevo (comentariosEN);
        return oid;
}

public void Modificar (int p_Comentarios_OID, string p_texto)
{
        ComentariosEN comentariosEN = null;

        //Initialized ComentariosEN
        comentariosEN = new ComentariosEN ();
        comentariosEN.Id = p_Comentarios_OID;
        comentariosEN.Texto = p_texto;
        //Call to ComentariosRepository

        _IComentariosRepository.Modificar (comentariosEN);
}

public void Borrar (int id
                    )
{
        _IComentariosRepository.Borrar (id);
}
}
}
