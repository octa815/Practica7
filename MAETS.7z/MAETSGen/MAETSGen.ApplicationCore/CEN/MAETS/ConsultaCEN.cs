

using System;
using System.Text;
using System.Collections.Generic;

using MAETSGen.ApplicationCore.Exceptions;

using MAETSGen.ApplicationCore.EN.MAETS;
using MAETSGen.ApplicationCore.IRepository.MAETS;


namespace MAETSGen.ApplicationCore.CEN.MAETS
{
/*
 *      Definition of the class ConsultaCEN
 *
 */
public partial class ConsultaCEN
{
private IConsultaRepository _IConsultaRepository;

public ConsultaCEN(IConsultaRepository _IConsultaRepository)
{
        this._IConsultaRepository = _IConsultaRepository;
}

public IConsultaRepository get_IConsultaRepository ()
{
        return this._IConsultaRepository;
}

public int Nuevo (string p_texto, int p_IDconsulta, string p_administrador, string p_usuario)
{
        ConsultaEN consultaEN = null;
        int oid;

        //Initialized ConsultaEN
        consultaEN = new ConsultaEN ();
        consultaEN.Texto = p_texto;

        consultaEN.IDconsulta = p_IDconsulta;


        if (p_administrador != null) {
                // El argumento p_administrador -> Property administrador es oid = false
                // Lista de oids IDconsulta
                consultaEN.Administrador = new MAETSGen.ApplicationCore.EN.MAETS.AdministradorEN ();
                consultaEN.Administrador.Dni = p_administrador;
        }


        if (p_usuario != null) {
                // El argumento p_usuario -> Property usuario es oid = false
                // Lista de oids IDconsulta
                consultaEN.Usuario = new MAETSGen.ApplicationCore.EN.MAETS.UsuarioEN ();
                consultaEN.Usuario.Dni = p_usuario;
        }



        oid = _IConsultaRepository.Nuevo (consultaEN);
        return oid;
}

public void Modificar (int p_Consulta_OID, string p_texto)
{
        ConsultaEN consultaEN = null;

        //Initialized ConsultaEN
        consultaEN = new ConsultaEN ();
        consultaEN.IDconsulta = p_Consulta_OID;
        consultaEN.Texto = p_texto;
        //Call to ConsultaRepository

        _IConsultaRepository.Modificar (consultaEN);
}

public void Borrar (int IDconsulta
                    )
{
        _IConsultaRepository.Borrar (IDconsulta);
}

public ConsultaEN LeeID (int IDconsulta
                         )
{
        ConsultaEN consultaEN = null;

        consultaEN = _IConsultaRepository.LeeID (IDconsulta);
        return consultaEN;
}

public System.Collections.Generic.IList<ConsultaEN> LeeTodos (int first, int size)
{
        System.Collections.Generic.IList<ConsultaEN> list = null;

        list = _IConsultaRepository.LeeTodos (first, size);
        return list;
}
}
}
