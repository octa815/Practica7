

using System;
using System.Text;
using System.Collections.Generic;

using MAETSGen.ApplicationCore.Exceptions;

using MAETSGen.ApplicationCore.EN.MAETS;
using MAETSGen.ApplicationCore.IRepository.MAETS;


namespace MAETSGen.ApplicationCore.CEN.MAETS
{
/*
 *      Definition of the class CopiaCEN
 *
 */
public partial class CopiaCEN
{
private ICopiaRepository _ICopiaRepository;

public CopiaCEN(ICopiaRepository _ICopiaRepository)
{
        this._ICopiaRepository = _ICopiaRepository;
}

public ICopiaRepository get_ICopiaRepository ()
{
        return this._ICopiaRepository;
}

public int Nuevo (int p_biblioteca, string p_juego, MAETSGen.ApplicationCore.Enumerated.MAETS.Estado_juegoEnum p_estado)
{
        CopiaEN copiaEN = null;
        int oid;

        //Initialized CopiaEN
        copiaEN = new CopiaEN ();

        if (p_biblioteca != -1) {
                // El argumento p_biblioteca -> Property biblioteca es oid = false
                // Lista de oids num_copia
                copiaEN.Biblioteca = new MAETSGen.ApplicationCore.EN.MAETS.BibliotecaEN ();
                copiaEN.Biblioteca.Id = p_biblioteca;
        }


        if (p_juego != null) {
                // El argumento p_juego -> Property juego es oid = false
                // Lista de oids num_copia
                copiaEN.Juego = new MAETSGen.ApplicationCore.EN.MAETS.JuegoEN ();
                copiaEN.Juego.Nombre = p_juego;
        }

        copiaEN.Estado = p_estado;



        oid = _ICopiaRepository.Nuevo (copiaEN);
        return oid;
}

public void Modificar (int p_Copia_OID, MAETSGen.ApplicationCore.Enumerated.MAETS.Estado_juegoEnum p_estado)
{
        CopiaEN copiaEN = null;

        //Initialized CopiaEN
        copiaEN = new CopiaEN ();
        copiaEN.Num_copia = p_Copia_OID;
        copiaEN.Estado = p_estado;
        //Call to CopiaRepository

        _ICopiaRepository.Modificar (copiaEN);
}

public void Borrar (int num_copia
                    )
{
        _ICopiaRepository.Borrar (num_copia);
}

public CopiaEN LeeID (int num_copia
                      )
{
        CopiaEN copiaEN = null;

        copiaEN = _ICopiaRepository.LeeID (num_copia);
        return copiaEN;
}

public System.Collections.Generic.IList<CopiaEN> LeeTodos (int first, int size)
{
        System.Collections.Generic.IList<CopiaEN> list = null;

        list = _ICopiaRepository.LeeTodos (first, size);
        return list;
}
public System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.CopiaEN> DameCopias (string n_game)
{
        return _ICopiaRepository.DameCopias (n_game);
}
public System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.CopiaEN> DameEstadoJuego (MAETSGen.ApplicationCore.Enumerated.MAETS.Estado_juegoEnum ? estad)
{
        return _ICopiaRepository.DameEstadoJuego (estad);
}
}
}
