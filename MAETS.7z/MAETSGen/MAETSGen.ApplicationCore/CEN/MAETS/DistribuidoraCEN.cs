

using System;
using System.Text;
using System.Collections.Generic;

using MAETSGen.ApplicationCore.Exceptions;

using MAETSGen.ApplicationCore.EN.MAETS;
using MAETSGen.ApplicationCore.IRepository.MAETS;


namespace MAETSGen.ApplicationCore.CEN.MAETS
{
/*
 *      Definition of the class DistribuidoraCEN
 *
 */
public partial class DistribuidoraCEN
{
private IDistribuidoraRepository _IDistribuidoraRepository;

public DistribuidoraCEN(IDistribuidoraRepository _IDistribuidoraRepository)
{
        this._IDistribuidoraRepository = _IDistribuidoraRepository;
}

public IDistribuidoraRepository get_IDistribuidoraRepository ()
{
        return this._IDistribuidoraRepository;
}

public int Nuevo (string p_nombre)
{
        DistribuidoraEN distribuidoraEN = null;
        int oid;

        //Initialized DistribuidoraEN
        distribuidoraEN = new DistribuidoraEN ();
        distribuidoraEN.Nombre = p_nombre;



        oid = _IDistribuidoraRepository.Nuevo (distribuidoraEN);
        return oid;
}

public void Modificar (int p_Distribuidora_OID, string p_nombre)
{
        DistribuidoraEN distribuidoraEN = null;

        //Initialized DistribuidoraEN
        distribuidoraEN = new DistribuidoraEN ();
        distribuidoraEN.ID_distrib = p_Distribuidora_OID;
        distribuidoraEN.Nombre = p_nombre;
        //Call to DistribuidoraRepository

        _IDistribuidoraRepository.Modificar (distribuidoraEN);
}

public void Borrar (int ID_distrib
                    )
{
        _IDistribuidoraRepository.Borrar (ID_distrib);
}
}
}
