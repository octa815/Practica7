

using System;
using System.Text;
using System.Collections.Generic;

using MAETSGen.ApplicationCore.Exceptions;

using MAETSGen.ApplicationCore.EN.MAETS;
using MAETSGen.ApplicationCore.IRepository.MAETS;


namespace MAETSGen.ApplicationCore.CEN.MAETS
{
/*
 *      Definition of the class JuegoCEN
 *
 */
public partial class JuegoCEN
{
private IJuegoRepository _IJuegoRepository;

public JuegoCEN(IJuegoRepository _IJuegoRepository)
{
        this._IJuegoRepository = _IJuegoRepository;
}

public IJuegoRepository get_IJuegoRepository ()
{
        return this._IJuegoRepository;
}

public string Nuevo (string p_nombre, Nullable<DateTime> p_feche_Lanz, float p_precio, int p_horas, string p_requisitos, int p_MAETS, string p_categorias, int p_distribuidora)
{
        JuegoEN juegoEN = null;
        string oid;

        //Initialized JuegoEN
        juegoEN = new JuegoEN ();
        juegoEN.Nombre = p_nombre;

        juegoEN.Feche_Lanz = p_feche_Lanz;

        juegoEN.Precio = p_precio;

        juegoEN.Horas = p_horas;

        juegoEN.Requisitos = p_requisitos;


        if (p_MAETS != -1) {
                // El argumento p_MAETS -> Property MAETS es oid = false
                // Lista de oids nombre
                juegoEN.MAETS = new MAETSGen.ApplicationCore.EN.MAETS.MAETSEN ();
                juegoEN.MAETS.Id = p_MAETS;
        }


        if (p_categorias != null) {
                // El argumento p_categorias -> Property categorias es oid = false
                // Lista de oids nombre
                juegoEN.Categorias = new MAETSGen.ApplicationCore.EN.MAETS.CategoriasEN ();
                juegoEN.Categorias.Cat = p_categorias;
        }


        if (p_distribuidora != -1) {
                // El argumento p_distribuidora -> Property distribuidora es oid = false
                // Lista de oids nombre
                juegoEN.Distribuidora = new MAETSGen.ApplicationCore.EN.MAETS.DistribuidoraEN ();
                juegoEN.Distribuidora.ID_distrib = p_distribuidora;
        }



        oid = _IJuegoRepository.Nuevo (juegoEN);
        return oid;
}

public void Modificar (string p_Juego_OID, Nullable<DateTime> p_feche_Lanz, float p_precio, int p_horas, string p_requisitos)
{
        JuegoEN juegoEN = null;

        //Initialized JuegoEN
        juegoEN = new JuegoEN ();
        juegoEN.Nombre = p_Juego_OID;
        juegoEN.Feche_Lanz = p_feche_Lanz;
        juegoEN.Precio = p_precio;
        juegoEN.Horas = p_horas;
        juegoEN.Requisitos = p_requisitos;
        //Call to JuegoRepository

        _IJuegoRepository.Modificar (juegoEN);
}

public void Borrar (string nombre
                    )
{
        _IJuegoRepository.Borrar (nombre);
}

public JuegoEN LeeID (string nombre
                      )
{
        JuegoEN juegoEN = null;

        juegoEN = _IJuegoRepository.LeeID (nombre);
        return juegoEN;
}

public System.Collections.Generic.IList<JuegoEN> LeeTodos (int first, int size)
{
        System.Collections.Generic.IList<JuegoEN> list = null;

        list = _IJuegoRepository.LeeTodos (first, size);
        return list;
}
public System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.JuegoEN> DameJuegoporCat (string cat_game)
{
        return _IJuegoRepository.DameJuegoporCat (cat_game);
}
}
}
