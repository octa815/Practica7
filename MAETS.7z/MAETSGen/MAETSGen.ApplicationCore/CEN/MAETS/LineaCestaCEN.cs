

using System;
using System.Text;
using System.Collections.Generic;

using MAETSGen.ApplicationCore.Exceptions;

using MAETSGen.ApplicationCore.EN.MAETS;
using MAETSGen.ApplicationCore.IRepository.MAETS;


namespace MAETSGen.ApplicationCore.CEN.MAETS
{
/*
 *      Definition of the class LineaCestaCEN
 *
 */
public partial class LineaCestaCEN
{
private ILineaCestaRepository _ILineaCestaRepository;

public LineaCestaCEN(ILineaCestaRepository _ILineaCestaRepository)
{
        this._ILineaCestaRepository = _ILineaCestaRepository;
}

public ILineaCestaRepository get_ILineaCestaRepository ()
{
        return this._ILineaCestaRepository;
}

public int Nuevo (int p_cesta, string p_juego)
{
        LineaCestaEN lineaCestaEN = null;
        int oid;

        //Initialized LineaCestaEN
        lineaCestaEN = new LineaCestaEN ();

        if (p_cesta != -1) {
                // El argumento p_cesta -> Property cesta es oid = false
                // Lista de oids id
                lineaCestaEN.Cesta = new MAETSGen.ApplicationCore.EN.MAETS.CestaEN ();
                lineaCestaEN.Cesta.Id_pedido = p_cesta;
        }


        if (p_juego != null) {
                // El argumento p_juego -> Property juego es oid = false
                // Lista de oids id
                lineaCestaEN.Juego = new MAETSGen.ApplicationCore.EN.MAETS.JuegoEN ();
                lineaCestaEN.Juego.Nombre = p_juego;
        }



        oid = _ILineaCestaRepository.Nuevo (lineaCestaEN);
        return oid;
}

public void Modificar (int p_LineaCesta_OID)
{
        LineaCestaEN lineaCestaEN = null;

        //Initialized LineaCestaEN
        lineaCestaEN = new LineaCestaEN ();
        lineaCestaEN.Id = p_LineaCesta_OID;
        //Call to LineaCestaRepository

        _ILineaCestaRepository.Modificar (lineaCestaEN);
}

public void Borrar (int id
                    )
{
        _ILineaCestaRepository.Borrar (id);
}
}
}
