

using System;
using System.Text;
using System.Collections.Generic;

using MAETSGen.ApplicationCore.Exceptions;

using MAETSGen.ApplicationCore.EN.MAETS;
using MAETSGen.ApplicationCore.IRepository.MAETS;


namespace MAETSGen.ApplicationCore.CEN.MAETS
{
/*
 *      Definition of the class LogroCEN
 *
 */
public partial class LogroCEN
{
private ILogroRepository _ILogroRepository;

public LogroCEN(ILogroRepository _ILogroRepository)
{
        this._ILogroRepository = _ILogroRepository;
}

public ILogroRepository get_ILogroRepository ()
{
        return this._ILogroRepository;
}

public int Nuevo (string p_nombre, string p_descrip)
{
        LogroEN logroEN = null;
        int oid;

        //Initialized LogroEN
        logroEN = new LogroEN ();
        logroEN.Nombre = p_nombre;

        logroEN.Descrip = p_descrip;



        oid = _ILogroRepository.Nuevo (logroEN);
        return oid;
}

public void Modificar (int p_Logro_OID, string p_nombre, string p_descrip)
{
        LogroEN logroEN = null;

        //Initialized LogroEN
        logroEN = new LogroEN ();
        logroEN.Id = p_Logro_OID;
        logroEN.Nombre = p_nombre;
        logroEN.Descrip = p_descrip;
        //Call to LogroRepository

        _ILogroRepository.Modificar (logroEN);
}

public void Borrar (int id
                    )
{
        _ILogroRepository.Borrar (id);
}

public LogroEN LeeID (int id
                      )
{
        LogroEN logroEN = null;

        logroEN = _ILogroRepository.LeeID (id);
        return logroEN;
}

public System.Collections.Generic.IList<LogroEN> LeeTodos (int first, int size)
{
        System.Collections.Generic.IList<LogroEN> list = null;

        list = _ILogroRepository.LeeTodos (first, size);
        return list;
}
}
}
