

using System;
using System.Text;
using System.Collections.Generic;

using MAETSGen.ApplicationCore.Exceptions;

using MAETSGen.ApplicationCore.EN.MAETS;
using MAETSGen.ApplicationCore.IRepository.MAETS;


namespace MAETSGen.ApplicationCore.CEN.MAETS
{
/*
 *      Definition of the class MAETSCEN
 *
 */
public partial class MAETSCEN
{
private IMAETSRepository _IMAETSRepository;

public MAETSCEN(IMAETSRepository _IMAETSRepository)
{
        this._IMAETSRepository = _IMAETSRepository;
}

public IMAETSRepository get_IMAETSRepository ()
{
        return this._IMAETSRepository;
}

public int Nuevo ()
{
        MAETSEN mAETSEN = null;
        int oid;

        //Initialized MAETSEN
        mAETSEN = new MAETSEN ();


        oid = _IMAETSRepository.Nuevo (mAETSEN);
        return oid;
}

public void Modificar (int p_MAETS_OID)
{
        MAETSEN mAETSEN = null;

        //Initialized MAETSEN
        mAETSEN = new MAETSEN ();
        mAETSEN.Id = p_MAETS_OID;
        //Call to MAETSRepository

        _IMAETSRepository.Modificar (mAETSEN);
}

public void Borrar (int id
                    )
{
        _IMAETSRepository.Borrar (id);
}
}
}
