

using System;
using System.Text;
using System.Collections.Generic;

using MAETSGen.ApplicationCore.Exceptions;

using MAETSGen.ApplicationCore.EN.MAETS;
using MAETSGen.ApplicationCore.IRepository.MAETS;


namespace MAETSGen.ApplicationCore.CEN.MAETS
{
/*
 *      Definition of the class UsuarioCEN
 *
 */
public partial class UsuarioCEN
{
private IUsuarioRepository _IUsuarioRepository;

public UsuarioCEN(IUsuarioRepository _IUsuarioRepository)
{
        this._IUsuarioRepository = _IUsuarioRepository;
}

public IUsuarioRepository get_IUsuarioRepository ()
{
        return this._IUsuarioRepository;
}

public string Nuevo (string p_dni, string p_pass, Nullable<DateTime> p_fechareg, string p_nombre, string p_email)
{
        UsuarioEN usuarioEN = null;
        string oid;

        //Initialized UsuarioEN
        usuarioEN = new UsuarioEN ();
        usuarioEN.Dni = p_dni;

        usuarioEN.Pass = p_pass;

        usuarioEN.Fechareg = p_fechareg;

        usuarioEN.Nombre = p_nombre;

        usuarioEN.Email = p_email;



        oid = _IUsuarioRepository.Nuevo (usuarioEN);
        return oid;
}

public void Modificar (string p_Usuario_OID, string p_pass, Nullable<DateTime> p_fechareg, string p_nombre, string p_email)
{
        UsuarioEN usuarioEN = null;

        //Initialized UsuarioEN
        usuarioEN = new UsuarioEN ();
        usuarioEN.Dni = p_Usuario_OID;
        usuarioEN.Pass = p_pass;
        usuarioEN.Fechareg = p_fechareg;
        usuarioEN.Nombre = p_nombre;
        usuarioEN.Email = p_email;
        //Call to UsuarioRepository

        _IUsuarioRepository.Modificar (usuarioEN);
}

public void Borrar (string dni
                    )
{
        _IUsuarioRepository.Borrar (dni);
}

public UsuarioEN LeeID (string dni
                        )
{
        UsuarioEN usuarioEN = null;

        usuarioEN = _IUsuarioRepository.LeeID (dni);
        return usuarioEN;
}

public System.Collections.Generic.IList<UsuarioEN> LeeTodos (int first, int size)
{
        System.Collections.Generic.IList<UsuarioEN> list = null;

        list = _IUsuarioRepository.LeeTodos (first, size);
        return list;
}
public System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.UsuarioEN> DameEmail (string usu)
{
        return _IUsuarioRepository.DameEmail (usu);
}
}
}
