
using System;
using System.Text;
using System.Collections.Generic;
using MAETSGen.ApplicationCore.Exceptions;
using MAETSGen.ApplicationCore.EN.MAETS;
using MAETSGen.ApplicationCore.IRepository.MAETS;


/*PROTECTED REGION ID(usingMAETSGen.ApplicationCore.CEN.MAETS_Cesta_cambiarPlan) ENABLED START*/
//  references to other libraries
/*PROTECTED REGION END*/

namespace MAETSGen.ApplicationCore.CEN.MAETS
{
public partial class CestaCEN
{
public void CambiarPlan (int p_oid, MAETSGen.ApplicationCore.Enumerated.MAETS.Tipo_PlanEnum p_plan)
{
        /*PROTECTED REGION ID(MAETSGen.ApplicationCore.CEN.MAETS_Cesta_cambiarPlan) ENABLED START*/

        // Write here your custom code...

        CestaEN ces = _ICestaRepository.LeeID (p_oid);

        if (ces.Plan_alq != p_plan) {
                ces.Plan_alq = p_plan;

                _ICestaRepository.ModifyDefault (ces);
        }
        else{
                Console.WriteLine ("______________________________________");
                Console.WriteLine ("No puede cambiar el plan por el mismo");
                Console.WriteLine ("______________________________________");
        }

        /*PROTECTED REGION END*/
}
}
}
