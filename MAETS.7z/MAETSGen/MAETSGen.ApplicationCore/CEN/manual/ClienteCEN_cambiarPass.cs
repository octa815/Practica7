
using System;
using System.Text;
using System.Collections.Generic;
using MAETSGen.ApplicationCore.Exceptions;
using MAETSGen.ApplicationCore.EN.MAETS;
using MAETSGen.ApplicationCore.IRepository.MAETS;


/*PROTECTED REGION ID(usingMAETSGen.ApplicationCore.CEN.MAETS_Cliente_cambiarPass) ENABLED START*/
//  references to other libraries
/*PROTECTED REGION END*/

namespace MAETSGen.ApplicationCore.CEN.MAETS
{
public partial class ClienteCEN
{
public void CambiarPass (string p_oid, string pass_old, string pass_new)
{
        /*PROTECTED REGION ID(MAETSGen.ApplicationCore.CEN.MAETS_Cliente_cambiarPass) ENABLED START*/

        // Write here your custom code...

        ClienteEN cli = _IClienteRepository.LeeID (p_oid);

        if (cli.Pass == pass_old) {
                cli.Pass = pass_new;

                _IClienteRepository.ModifyDefault (cli);
        }
        else{
                Console.WriteLine ("_____________________________________________________");
                Console.WriteLine ("La contrasenya antigua no coincide con la introducida");
                Console.WriteLine ("_____________________________________________________");
        }


        /*PROTECTED REGION END*/
}
}
}
