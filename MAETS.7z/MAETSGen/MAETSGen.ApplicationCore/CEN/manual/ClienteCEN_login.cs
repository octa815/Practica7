
using System;
using System.Text;
using System.Collections.Generic;
using MAETSGen.ApplicationCore.Exceptions;
using MAETSGen.ApplicationCore.EN.MAETS;
using MAETSGen.ApplicationCore.IRepository.MAETS;


/*PROTECTED REGION ID(usingMAETSGen.ApplicationCore.CEN.MAETS_Cliente_login) ENABLED START*/
//  references to other libraries
/*PROTECTED REGION END*/

namespace MAETSGen.ApplicationCore.CEN.MAETS
{
public partial class ClienteCEN
{
public string Login (string p_Cliente_OID, string p_pass)
{
        /*PROTECTED REGION ID(MAETSGen.ApplicationCore.CEN.MAETS_Cliente_login) ENABLED START*/
        string result = null;
        ClienteEN en = _IClienteRepository.ReadOIDDefault (p_Cliente_OID);

        if (en.Pass.Equals (Utils.Util.GetEncondeMD5 (p_pass)))
                result = this.GetToken (en.Dni);

        return result;
        /*PROTECTED REGION END*/
}
}
}
