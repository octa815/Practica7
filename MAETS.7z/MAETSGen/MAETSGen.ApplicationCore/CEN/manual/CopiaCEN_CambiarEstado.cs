
using System;
using System.Text;
using System.Collections.Generic;
using MAETSGen.ApplicationCore.Exceptions;
using MAETSGen.ApplicationCore.EN.MAETS;
using MAETSGen.ApplicationCore.IRepository.MAETS;


/*PROTECTED REGION ID(usingMAETSGen.ApplicationCore.CEN.MAETS_Copia_CambiarEstado) ENABLED START*/
//  references to other libraries
/*PROTECTED REGION END*/

namespace MAETSGen.ApplicationCore.CEN.MAETS
{
public partial class CopiaCEN
{
public void CambiarEstado (int p_oid, MAETSGen.ApplicationCore.Enumerated.MAETS.Estado_juegoEnum p_estado)
{
        /*PROTECTED REGION ID(MAETSGen.ApplicationCore.CEN.MAETS_Copia_CambiarEstado) ENABLED START*/

        // Write here your custom code...

        CopiaEN copia = _ICopiaRepository.LeeID (p_oid);

        if (copia.Estado != Enumerated.MAETS.Estado_juegoEnum.adquirido) {
                copia.Estado = p_estado;

                _ICopiaRepository.ModifyDefault (copia);
        }
        else{
                Console.WriteLine ("_____________________");
                Console.WriteLine ("Ya ha sido adquirido");
                Console.WriteLine ("_____________________");
        }

        /*PROTECTED REGION END*/
}
}
}
