
using System;
using System.Text;
using System.Collections.Generic;
using MAETSGen.ApplicationCore.Exceptions;
using MAETSGen.ApplicationCore.EN.MAETS;
using MAETSGen.ApplicationCore.IRepository.MAETS;


/*PROTECTED REGION ID(usingMAETSGen.ApplicationCore.CEN.MAETS_Usuario_cambiarCorreo) ENABLED START*/
//  references to other libraries
/*PROTECTED REGION END*/

namespace MAETSGen.ApplicationCore.CEN.MAETS
{
public partial class UsuarioCEN
{
public void CambiarCorreo (string p_oid, string pass, string mail)
{
        /*PROTECTED REGION ID(MAETSGen.ApplicationCore.CEN.MAETS_Usuario_cambiarCorreo) ENABLED START*/

        // Write here your custom code...

        UsuarioEN us = _IUsuarioRepository.LeeID (p_oid);

        if (us.Pass == pass) {
                if (us.Email != mail) {
                        us.Email = mail;
                        _IUsuarioRepository.ModifyDefault (us);
                }
                else{
                        Console.WriteLine ("_________________________________");
                        Console.WriteLine ("El nuevo coincide con el anterior");
                        Console.WriteLine ("_________________________________");
                }
        }
        else{
                Console.WriteLine ("______________________________");
                Console.WriteLine ("Las contrasenyas no coinciden.");
                Console.WriteLine ("______________________________");
        }

        /*PROTECTED REGION END*/
}
}
}
