
using System;
using System.Text;
using System.Collections.Generic;
using MAETSGen.ApplicationCore.Exceptions;
using MAETSGen.ApplicationCore.EN.MAETS;
using MAETSGen.ApplicationCore.IRepository.MAETS;


/*PROTECTED REGION ID(usingMAETSGen.ApplicationCore.CEN.MAETS_Usuario_verificarLogin) ENABLED START*/
//  references to other libraries
/*PROTECTED REGION END*/

namespace MAETSGen.ApplicationCore.CEN.MAETS
{
public partial class UsuarioCEN
{
public void VerificarLogin (string p_oid)
{
        /*PROTECTED REGION ID(MAETSGen.ApplicationCore.CEN.MAETS_Usuario_verificarLogin) ENABLED START*/

        // Write here your custom code...

        throw new NotImplementedException ("Method VerificarLogin() not yet implemented.");

        /*PROTECTED REGION END*/
}
}
}
