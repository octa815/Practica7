
using System;
using System.Text;
using System.Collections.Generic;
using MAETSGen.ApplicationCore.Exceptions;
using MAETSGen.ApplicationCore.EN.MAETS;
using MAETSGen.ApplicationCore.IRepository.MAETS;
using MAETSGen.ApplicationCore.CEN.MAETS;



namespace MAETSGen.ApplicationCore.CP.MAETS
{
public partial class AdministradorCP : GenericBasicCP
{
public AdministradorCP(GenericSessionCP currentSession)
        : base (currentSession)
{
}
}
}
