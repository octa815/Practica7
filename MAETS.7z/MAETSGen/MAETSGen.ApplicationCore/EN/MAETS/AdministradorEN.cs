
using System;
// Definición clase AdministradorEN
namespace MAETSGen.ApplicationCore.EN.MAETS
{
public partial class AdministradorEN                                                                        : MAETSGen.ApplicationCore.EN.MAETS.ClienteEN


{
/**
 *	Atributo consultas
 */
private System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.ConsultaEN> consultas;






public virtual System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.ConsultaEN> Consultas {
        get { return consultas; } set { consultas = value;  }
}





public AdministradorEN() : base ()
{
        consultas = new System.Collections.Generic.List<MAETSGen.ApplicationCore.EN.MAETS.ConsultaEN>();
}



public AdministradorEN(string dni, System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.ConsultaEN> consultas
                       , string pass, System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.CestaEN> cesta, System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.LogroEN> logro, MAETSGen.ApplicationCore.EN.MAETS.BibliotecaEN bibliotecas, System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.ComentariosEN> comentarioss, Nullable<DateTime> fechareg
                       )
{
        this.init (Dni, consultas, pass, cesta, logro, bibliotecas, comentarioss, fechareg);
}


public AdministradorEN(AdministradorEN administrador)
{
        this.init (administrador.Dni, administrador.Consultas, administrador.Pass, administrador.Cesta, administrador.Logro, administrador.Bibliotecas, administrador.Comentarioss, administrador.Fechareg);
}

private void init (string dni
                   , System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.ConsultaEN> consultas, string pass, System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.CestaEN> cesta, System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.LogroEN> logro, MAETSGen.ApplicationCore.EN.MAETS.BibliotecaEN bibliotecas, System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.ComentariosEN> comentarioss, Nullable<DateTime> fechareg)
{
        this.Dni = dni;


        this.Consultas = consultas;

        this.Pass = pass;

        this.Cesta = cesta;

        this.Logro = logro;

        this.Bibliotecas = bibliotecas;

        this.Comentarioss = comentarioss;

        this.Fechareg = fechareg;
}

public override bool Equals (object obj)
{
        if (obj == null)
                return false;
        AdministradorEN t = obj as AdministradorEN;
        if (t == null)
                return false;
        if (Dni.Equals (t.Dni))
                return true;
        else
                return false;
}

public override int GetHashCode ()
{
        int hash = 13;

        hash += this.Dni.GetHashCode ();
        return hash;
}
}
}
