
using System;
// Definición clase BibliotecaEN
namespace MAETSGen.ApplicationCore.EN.MAETS
{
public partial class BibliotecaEN
{
/**
 *	Atributo id
 */
private int id;



/**
 *	Atributo cliente
 */
private MAETSGen.ApplicationCore.EN.MAETS.ClienteEN cliente;



/**
 *	Atributo copia
 */
private System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.CopiaEN> copia;






public virtual int Id {
        get { return id; } set { id = value;  }
}



public virtual MAETSGen.ApplicationCore.EN.MAETS.ClienteEN Cliente {
        get { return cliente; } set { cliente = value;  }
}



public virtual System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.CopiaEN> Copia {
        get { return copia; } set { copia = value;  }
}





public BibliotecaEN()
{
        copia = new System.Collections.Generic.List<MAETSGen.ApplicationCore.EN.MAETS.CopiaEN>();
}



public BibliotecaEN(int id, MAETSGen.ApplicationCore.EN.MAETS.ClienteEN cliente, System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.CopiaEN> copia
                    )
{
        this.init (Id, cliente, copia);
}


public BibliotecaEN(BibliotecaEN biblioteca)
{
        this.init (biblioteca.Id, biblioteca.Cliente, biblioteca.Copia);
}

private void init (int id
                   , MAETSGen.ApplicationCore.EN.MAETS.ClienteEN cliente, System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.CopiaEN> copia)
{
        this.Id = id;


        this.Cliente = cliente;

        this.Copia = copia;
}

public override bool Equals (object obj)
{
        if (obj == null)
                return false;
        BibliotecaEN t = obj as BibliotecaEN;
        if (t == null)
                return false;
        if (Id.Equals (t.Id))
                return true;
        else
                return false;
}

public override int GetHashCode ()
{
        int hash = 13;

        hash += this.Id.GetHashCode ();
        return hash;
}
}
}
