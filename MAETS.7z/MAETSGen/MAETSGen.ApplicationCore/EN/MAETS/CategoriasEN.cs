
using System;
// Definición clase CategoriasEN
namespace MAETSGen.ApplicationCore.EN.MAETS
{
public partial class CategoriasEN
{
/**
 *	Atributo cat
 */
private string cat;



/**
 *	Atributo juego
 */
private System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.JuegoEN> juego;



/**
 *	Atributo subcategorias
 */
private System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.CategoriasEN> subcategorias;



/**
 *	Atributo supercategoria
 */
private MAETSGen.ApplicationCore.EN.MAETS.CategoriasEN supercategoria;






public virtual string Cat {
        get { return cat; } set { cat = value;  }
}



public virtual System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.JuegoEN> Juego {
        get { return juego; } set { juego = value;  }
}



public virtual System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.CategoriasEN> Subcategorias {
        get { return subcategorias; } set { subcategorias = value;  }
}



public virtual MAETSGen.ApplicationCore.EN.MAETS.CategoriasEN Supercategoria {
        get { return supercategoria; } set { supercategoria = value;  }
}





public CategoriasEN()
{
        juego = new System.Collections.Generic.List<MAETSGen.ApplicationCore.EN.MAETS.JuegoEN>();
        subcategorias = new System.Collections.Generic.List<MAETSGen.ApplicationCore.EN.MAETS.CategoriasEN>();
}



public CategoriasEN(string cat, System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.JuegoEN> juego, System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.CategoriasEN> subcategorias, MAETSGen.ApplicationCore.EN.MAETS.CategoriasEN supercategoria
                    )
{
        this.init (Cat, juego, subcategorias, supercategoria);
}


public CategoriasEN(CategoriasEN categorias)
{
        this.init (categorias.Cat, categorias.Juego, categorias.Subcategorias, categorias.Supercategoria);
}

private void init (string cat
                   , System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.JuegoEN> juego, System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.CategoriasEN> subcategorias, MAETSGen.ApplicationCore.EN.MAETS.CategoriasEN supercategoria)
{
        this.Cat = cat;


        this.Juego = juego;

        this.Subcategorias = subcategorias;

        this.Supercategoria = supercategoria;
}

public override bool Equals (object obj)
{
        if (obj == null)
                return false;
        CategoriasEN t = obj as CategoriasEN;
        if (t == null)
                return false;
        if (Cat.Equals (t.Cat))
                return true;
        else
                return false;
}

public override int GetHashCode ()
{
        int hash = 13;

        hash += this.Cat.GetHashCode ();
        return hash;
}
}
}
