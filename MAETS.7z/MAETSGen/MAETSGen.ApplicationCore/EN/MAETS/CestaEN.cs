
using System;
// Definición clase CestaEN
namespace MAETSGen.ApplicationCore.EN.MAETS
{
public partial class CestaEN
{
/**
 *	Atributo id_pedido
 */
private int id_pedido;



/**
 *	Atributo cliente
 */
private MAETSGen.ApplicationCore.EN.MAETS.ClienteEN cliente;



/**
 *	Atributo fecha_add
 */
private Nullable<DateTime> fecha_add;



/**
 *	Atributo estado
 */
private bool estado;



/**
 *	Atributo lineasCesta
 */
private System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.LineaCestaEN> lineasCesta;



/**
 *	Atributo plan_alq
 */
private MAETSGen.ApplicationCore.Enumerated.MAETS.Tipo_PlanEnum plan_alq;






public virtual int Id_pedido {
        get { return id_pedido; } set { id_pedido = value;  }
}



public virtual MAETSGen.ApplicationCore.EN.MAETS.ClienteEN Cliente {
        get { return cliente; } set { cliente = value;  }
}



public virtual Nullable<DateTime> Fecha_add {
        get { return fecha_add; } set { fecha_add = value;  }
}



public virtual bool Estado {
        get { return estado; } set { estado = value;  }
}



public virtual System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.LineaCestaEN> LineasCesta {
        get { return lineasCesta; } set { lineasCesta = value;  }
}



public virtual MAETSGen.ApplicationCore.Enumerated.MAETS.Tipo_PlanEnum Plan_alq {
        get { return plan_alq; } set { plan_alq = value;  }
}





public CestaEN()
{
        lineasCesta = new System.Collections.Generic.List<MAETSGen.ApplicationCore.EN.MAETS.LineaCestaEN>();
}



public CestaEN(int id_pedido, MAETSGen.ApplicationCore.EN.MAETS.ClienteEN cliente, Nullable<DateTime> fecha_add, bool estado, System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.LineaCestaEN> lineasCesta, MAETSGen.ApplicationCore.Enumerated.MAETS.Tipo_PlanEnum plan_alq
               )
{
        this.init (Id_pedido, cliente, fecha_add, estado, lineasCesta, plan_alq);
}


public CestaEN(CestaEN cesta)
{
        this.init (cesta.Id_pedido, cesta.Cliente, cesta.Fecha_add, cesta.Estado, cesta.LineasCesta, cesta.Plan_alq);
}

private void init (int id_pedido
                   , MAETSGen.ApplicationCore.EN.MAETS.ClienteEN cliente, Nullable<DateTime> fecha_add, bool estado, System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.LineaCestaEN> lineasCesta, MAETSGen.ApplicationCore.Enumerated.MAETS.Tipo_PlanEnum plan_alq)
{
        this.Id_pedido = id_pedido;


        this.Cliente = cliente;

        this.Fecha_add = fecha_add;

        this.Estado = estado;

        this.LineasCesta = lineasCesta;

        this.Plan_alq = plan_alq;
}

public override bool Equals (object obj)
{
        if (obj == null)
                return false;
        CestaEN t = obj as CestaEN;
        if (t == null)
                return false;
        if (Id_pedido.Equals (t.Id_pedido))
                return true;
        else
                return false;
}

public override int GetHashCode ()
{
        int hash = 13;

        hash += this.Id_pedido.GetHashCode ();
        return hash;
}
}
}
