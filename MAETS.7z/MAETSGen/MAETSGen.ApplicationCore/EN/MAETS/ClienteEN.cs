
using System;
// Definición clase ClienteEN
namespace MAETSGen.ApplicationCore.EN.MAETS
{
public partial class ClienteEN
{
/**
 *	Atributo dni
 */
private string dni;



/**
 *	Atributo pass
 */
private string pass;



/**
 *	Atributo cesta
 */
private System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.CestaEN> cesta;



/**
 *	Atributo logro
 */
private System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.LogroEN> logro;



/**
 *	Atributo bibliotecas
 */
private MAETSGen.ApplicationCore.EN.MAETS.BibliotecaEN bibliotecas;



/**
 *	Atributo comentarioss
 */
private System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.ComentariosEN> comentarioss;



/**
 *	Atributo fechareg
 */
private Nullable<DateTime> fechareg;






public virtual string Dni {
        get { return dni; } set { dni = value;  }
}



public virtual string Pass {
        get { return pass; } set { pass = value;  }
}



public virtual System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.CestaEN> Cesta {
        get { return cesta; } set { cesta = value;  }
}



public virtual System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.LogroEN> Logro {
        get { return logro; } set { logro = value;  }
}



public virtual MAETSGen.ApplicationCore.EN.MAETS.BibliotecaEN Bibliotecas {
        get { return bibliotecas; } set { bibliotecas = value;  }
}



public virtual System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.ComentariosEN> Comentarioss {
        get { return comentarioss; } set { comentarioss = value;  }
}



public virtual Nullable<DateTime> Fechareg {
        get { return fechareg; } set { fechareg = value;  }
}





public ClienteEN()
{
        cesta = new System.Collections.Generic.List<MAETSGen.ApplicationCore.EN.MAETS.CestaEN>();
        logro = new System.Collections.Generic.List<MAETSGen.ApplicationCore.EN.MAETS.LogroEN>();
        comentarioss = new System.Collections.Generic.List<MAETSGen.ApplicationCore.EN.MAETS.ComentariosEN>();
}



public ClienteEN(string dni, string pass, System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.CestaEN> cesta, System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.LogroEN> logro, MAETSGen.ApplicationCore.EN.MAETS.BibliotecaEN bibliotecas, System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.ComentariosEN> comentarioss, Nullable<DateTime> fechareg
                 )
{
        this.init (Dni, pass, cesta, logro, bibliotecas, comentarioss, fechareg);
}


public ClienteEN(ClienteEN cliente)
{
        this.init (cliente.Dni, cliente.Pass, cliente.Cesta, cliente.Logro, cliente.Bibliotecas, cliente.Comentarioss, cliente.Fechareg);
}

private void init (string dni
                   , string pass, System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.CestaEN> cesta, System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.LogroEN> logro, MAETSGen.ApplicationCore.EN.MAETS.BibliotecaEN bibliotecas, System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.ComentariosEN> comentarioss, Nullable<DateTime> fechareg)
{
        this.Dni = dni;


        this.Pass = pass;

        this.Cesta = cesta;

        this.Logro = logro;

        this.Bibliotecas = bibliotecas;

        this.Comentarioss = comentarioss;

        this.Fechareg = fechareg;
}

public override bool Equals (object obj)
{
        if (obj == null)
                return false;
        ClienteEN t = obj as ClienteEN;
        if (t == null)
                return false;
        if (Dni.Equals (t.Dni))
                return true;
        else
                return false;
}

public override int GetHashCode ()
{
        int hash = 13;

        hash += this.Dni.GetHashCode ();
        return hash;
}
}
}
