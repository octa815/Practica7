
using System;
// Definición clase ComentariosEN
namespace MAETSGen.ApplicationCore.EN.MAETS
{
public partial class ComentariosEN
{
/**
 *	Atributo id
 */
private int id;



/**
 *	Atributo cliente
 */
private MAETSGen.ApplicationCore.EN.MAETS.ClienteEN cliente;



/**
 *	Atributo juego
 */
private MAETSGen.ApplicationCore.EN.MAETS.JuegoEN juego;



/**
 *	Atributo texto
 */
private string texto;






public virtual int Id {
        get { return id; } set { id = value;  }
}



public virtual MAETSGen.ApplicationCore.EN.MAETS.ClienteEN Cliente {
        get { return cliente; } set { cliente = value;  }
}



public virtual MAETSGen.ApplicationCore.EN.MAETS.JuegoEN Juego {
        get { return juego; } set { juego = value;  }
}



public virtual string Texto {
        get { return texto; } set { texto = value;  }
}





public ComentariosEN()
{
}



public ComentariosEN(int id, MAETSGen.ApplicationCore.EN.MAETS.ClienteEN cliente, MAETSGen.ApplicationCore.EN.MAETS.JuegoEN juego, string texto
                     )
{
        this.init (Id, cliente, juego, texto);
}


public ComentariosEN(ComentariosEN comentarios)
{
        this.init (comentarios.Id, comentarios.Cliente, comentarios.Juego, comentarios.Texto);
}

private void init (int id
                   , MAETSGen.ApplicationCore.EN.MAETS.ClienteEN cliente, MAETSGen.ApplicationCore.EN.MAETS.JuegoEN juego, string texto)
{
        this.Id = id;


        this.Cliente = cliente;

        this.Juego = juego;

        this.Texto = texto;
}

public override bool Equals (object obj)
{
        if (obj == null)
                return false;
        ComentariosEN t = obj as ComentariosEN;
        if (t == null)
                return false;
        if (Id.Equals (t.Id))
                return true;
        else
                return false;
}

public override int GetHashCode ()
{
        int hash = 13;

        hash += this.Id.GetHashCode ();
        return hash;
}
}
}
