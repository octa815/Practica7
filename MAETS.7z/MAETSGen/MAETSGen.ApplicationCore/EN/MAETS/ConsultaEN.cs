
using System;
// Definición clase ConsultaEN
namespace MAETSGen.ApplicationCore.EN.MAETS
{
public partial class ConsultaEN
{
/**
 *	Atributo texto
 */
private string texto;



/**
 *	Atributo iDconsulta
 */
private int iDconsulta;



/**
 *	Atributo administrador
 */
private MAETSGen.ApplicationCore.EN.MAETS.AdministradorEN administrador;



/**
 *	Atributo usuario
 */
private MAETSGen.ApplicationCore.EN.MAETS.UsuarioEN usuario;






public virtual string Texto {
        get { return texto; } set { texto = value;  }
}



public virtual int IDconsulta {
        get { return iDconsulta; } set { iDconsulta = value;  }
}



public virtual MAETSGen.ApplicationCore.EN.MAETS.AdministradorEN Administrador {
        get { return administrador; } set { administrador = value;  }
}



public virtual MAETSGen.ApplicationCore.EN.MAETS.UsuarioEN Usuario {
        get { return usuario; } set { usuario = value;  }
}





public ConsultaEN()
{
}



public ConsultaEN(int iDconsulta, string texto, MAETSGen.ApplicationCore.EN.MAETS.AdministradorEN administrador, MAETSGen.ApplicationCore.EN.MAETS.UsuarioEN usuario
                  )
{
        this.init (IDconsulta, texto, administrador, usuario);
}


public ConsultaEN(ConsultaEN consulta)
{
        this.init (consulta.IDconsulta, consulta.Texto, consulta.Administrador, consulta.Usuario);
}

private void init (int IDconsulta
                   , string texto, MAETSGen.ApplicationCore.EN.MAETS.AdministradorEN administrador, MAETSGen.ApplicationCore.EN.MAETS.UsuarioEN usuario)
{
        this.IDconsulta = IDconsulta;


        this.Texto = texto;

        this.Administrador = administrador;

        this.Usuario = usuario;
}

public override bool Equals (object obj)
{
        if (obj == null)
                return false;
        ConsultaEN t = obj as ConsultaEN;
        if (t == null)
                return false;
        if (IDconsulta.Equals (t.IDconsulta))
                return true;
        else
                return false;
}

public override int GetHashCode ()
{
        int hash = 13;

        hash += this.IDconsulta.GetHashCode ();
        return hash;
}
}
}
