
using System;
// Definición clase CopiaEN
namespace MAETSGen.ApplicationCore.EN.MAETS
{
public partial class CopiaEN
{
/**
 *	Atributo num_copia
 */
private int num_copia;



/**
 *	Atributo biblioteca
 */
private MAETSGen.ApplicationCore.EN.MAETS.BibliotecaEN biblioteca;



/**
 *	Atributo juego
 */
private MAETSGen.ApplicationCore.EN.MAETS.JuegoEN juego;



/**
 *	Atributo estado
 */
private MAETSGen.ApplicationCore.Enumerated.MAETS.Estado_juegoEnum estado;






public virtual int Num_copia {
        get { return num_copia; } set { num_copia = value;  }
}



public virtual MAETSGen.ApplicationCore.EN.MAETS.BibliotecaEN Biblioteca {
        get { return biblioteca; } set { biblioteca = value;  }
}



public virtual MAETSGen.ApplicationCore.EN.MAETS.JuegoEN Juego {
        get { return juego; } set { juego = value;  }
}



public virtual MAETSGen.ApplicationCore.Enumerated.MAETS.Estado_juegoEnum Estado {
        get { return estado; } set { estado = value;  }
}





public CopiaEN()
{
}



public CopiaEN(int num_copia, MAETSGen.ApplicationCore.EN.MAETS.BibliotecaEN biblioteca, MAETSGen.ApplicationCore.EN.MAETS.JuegoEN juego, MAETSGen.ApplicationCore.Enumerated.MAETS.Estado_juegoEnum estado
               )
{
        this.init (Num_copia, biblioteca, juego, estado);
}


public CopiaEN(CopiaEN copia)
{
        this.init (copia.Num_copia, copia.Biblioteca, copia.Juego, copia.Estado);
}

private void init (int num_copia
                   , MAETSGen.ApplicationCore.EN.MAETS.BibliotecaEN biblioteca, MAETSGen.ApplicationCore.EN.MAETS.JuegoEN juego, MAETSGen.ApplicationCore.Enumerated.MAETS.Estado_juegoEnum estado)
{
        this.Num_copia = num_copia;


        this.Biblioteca = biblioteca;

        this.Juego = juego;

        this.Estado = estado;
}

public override bool Equals (object obj)
{
        if (obj == null)
                return false;
        CopiaEN t = obj as CopiaEN;
        if (t == null)
                return false;
        if (Num_copia.Equals (t.Num_copia))
                return true;
        else
                return false;
}

public override int GetHashCode ()
{
        int hash = 13;

        hash += this.Num_copia.GetHashCode ();
        return hash;
}
}
}
