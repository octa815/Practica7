
using System;
// Definición clase DistribuidoraEN
namespace MAETSGen.ApplicationCore.EN.MAETS
{
public partial class DistribuidoraEN
{
/**
 *	Atributo iD_distrib
 */
private int iD_distrib;



/**
 *	Atributo nombre
 */
private string nombre;



/**
 *	Atributo juego
 */
private System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.JuegoEN> juego;






public virtual int ID_distrib {
        get { return iD_distrib; } set { iD_distrib = value;  }
}



public virtual string Nombre {
        get { return nombre; } set { nombre = value;  }
}



public virtual System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.JuegoEN> Juego {
        get { return juego; } set { juego = value;  }
}





public DistribuidoraEN()
{
        juego = new System.Collections.Generic.List<MAETSGen.ApplicationCore.EN.MAETS.JuegoEN>();
}



public DistribuidoraEN(int iD_distrib, string nombre, System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.JuegoEN> juego
                       )
{
        this.init (ID_distrib, nombre, juego);
}


public DistribuidoraEN(DistribuidoraEN distribuidora)
{
        this.init (distribuidora.ID_distrib, distribuidora.Nombre, distribuidora.Juego);
}

private void init (int ID_distrib
                   , string nombre, System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.JuegoEN> juego)
{
        this.ID_distrib = ID_distrib;


        this.Nombre = nombre;

        this.Juego = juego;
}

public override bool Equals (object obj)
{
        if (obj == null)
                return false;
        DistribuidoraEN t = obj as DistribuidoraEN;
        if (t == null)
                return false;
        if (ID_distrib.Equals (t.ID_distrib))
                return true;
        else
                return false;
}

public override int GetHashCode ()
{
        int hash = 13;

        hash += this.ID_distrib.GetHashCode ();
        return hash;
}
}
}
