
using System;
// Definición clase JuegoEN
namespace MAETSGen.ApplicationCore.EN.MAETS
{
public partial class JuegoEN
{
/**
 *	Atributo nombre
 */
private string nombre;



/**
 *	Atributo feche_Lanz
 */
private Nullable<DateTime> feche_Lanz;



/**
 *	Atributo precio
 */
private float precio;



/**
 *	Atributo horas
 */
private int horas;



/**
 *	Atributo requisitos
 */
private string requisitos;



/**
 *	Atributo mAETS
 */
private MAETSGen.ApplicationCore.EN.MAETS.MAETSEN mAETS;



/**
 *	Atributo comentarios
 */
private System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.ComentariosEN> comentarios;



/**
 *	Atributo categorias
 */
private MAETSGen.ApplicationCore.EN.MAETS.CategoriasEN categorias;



/**
 *	Atributo distribuidora
 */
private MAETSGen.ApplicationCore.EN.MAETS.DistribuidoraEN distribuidora;



/**
 *	Atributo lineaCesta
 */
private System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.LineaCestaEN> lineaCesta;



/**
 *	Atributo copia
 */
private System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.CopiaEN> copia;






public virtual string Nombre {
        get { return nombre; } set { nombre = value;  }
}



public virtual Nullable<DateTime> Feche_Lanz {
        get { return feche_Lanz; } set { feche_Lanz = value;  }
}



public virtual float Precio {
        get { return precio; } set { precio = value;  }
}



public virtual int Horas {
        get { return horas; } set { horas = value;  }
}



public virtual string Requisitos {
        get { return requisitos; } set { requisitos = value;  }
}



public virtual MAETSGen.ApplicationCore.EN.MAETS.MAETSEN MAETS {
        get { return mAETS; } set { mAETS = value;  }
}



public virtual System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.ComentariosEN> Comentarios {
        get { return comentarios; } set { comentarios = value;  }
}



public virtual MAETSGen.ApplicationCore.EN.MAETS.CategoriasEN Categorias {
        get { return categorias; } set { categorias = value;  }
}



public virtual MAETSGen.ApplicationCore.EN.MAETS.DistribuidoraEN Distribuidora {
        get { return distribuidora; } set { distribuidora = value;  }
}



public virtual System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.LineaCestaEN> LineaCesta {
        get { return lineaCesta; } set { lineaCesta = value;  }
}



public virtual System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.CopiaEN> Copia {
        get { return copia; } set { copia = value;  }
}





public JuegoEN()
{
        comentarios = new System.Collections.Generic.List<MAETSGen.ApplicationCore.EN.MAETS.ComentariosEN>();
        lineaCesta = new System.Collections.Generic.List<MAETSGen.ApplicationCore.EN.MAETS.LineaCestaEN>();
        copia = new System.Collections.Generic.List<MAETSGen.ApplicationCore.EN.MAETS.CopiaEN>();
}



public JuegoEN(string nombre, Nullable<DateTime> feche_Lanz, float precio, int horas, string requisitos, MAETSGen.ApplicationCore.EN.MAETS.MAETSEN mAETS, System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.ComentariosEN> comentarios, MAETSGen.ApplicationCore.EN.MAETS.CategoriasEN categorias, MAETSGen.ApplicationCore.EN.MAETS.DistribuidoraEN distribuidora, System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.LineaCestaEN> lineaCesta, System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.CopiaEN> copia
               )
{
        this.init (Nombre, feche_Lanz, precio, horas, requisitos, mAETS, comentarios, categorias, distribuidora, lineaCesta, copia);
}


public JuegoEN(JuegoEN juego)
{
        this.init (juego.Nombre, juego.Feche_Lanz, juego.Precio, juego.Horas, juego.Requisitos, juego.MAETS, juego.Comentarios, juego.Categorias, juego.Distribuidora, juego.LineaCesta, juego.Copia);
}

private void init (string nombre
                   , Nullable<DateTime> feche_Lanz, float precio, int horas, string requisitos, MAETSGen.ApplicationCore.EN.MAETS.MAETSEN mAETS, System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.ComentariosEN> comentarios, MAETSGen.ApplicationCore.EN.MAETS.CategoriasEN categorias, MAETSGen.ApplicationCore.EN.MAETS.DistribuidoraEN distribuidora, System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.LineaCestaEN> lineaCesta, System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.CopiaEN> copia)
{
        this.Nombre = nombre;


        this.Feche_Lanz = feche_Lanz;

        this.Precio = precio;

        this.Horas = horas;

        this.Requisitos = requisitos;

        this.MAETS = mAETS;

        this.Comentarios = comentarios;

        this.Categorias = categorias;

        this.Distribuidora = distribuidora;

        this.LineaCesta = lineaCesta;

        this.Copia = copia;
}

public override bool Equals (object obj)
{
        if (obj == null)
                return false;
        JuegoEN t = obj as JuegoEN;
        if (t == null)
                return false;
        if (Nombre.Equals (t.Nombre))
                return true;
        else
                return false;
}

public override int GetHashCode ()
{
        int hash = 13;

        hash += this.Nombre.GetHashCode ();
        return hash;
}
}
}
