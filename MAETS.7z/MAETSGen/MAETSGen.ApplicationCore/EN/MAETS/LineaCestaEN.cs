
using System;
// Definición clase LineaCestaEN
namespace MAETSGen.ApplicationCore.EN.MAETS
{
public partial class LineaCestaEN
{
/**
 *	Atributo cesta
 */
private MAETSGen.ApplicationCore.EN.MAETS.CestaEN cesta;



/**
 *	Atributo id
 */
private int id;



/**
 *	Atributo juego
 */
private MAETSGen.ApplicationCore.EN.MAETS.JuegoEN juego;






public virtual MAETSGen.ApplicationCore.EN.MAETS.CestaEN Cesta {
        get { return cesta; } set { cesta = value;  }
}



public virtual int Id {
        get { return id; } set { id = value;  }
}



public virtual MAETSGen.ApplicationCore.EN.MAETS.JuegoEN Juego {
        get { return juego; } set { juego = value;  }
}





public LineaCestaEN()
{
}



public LineaCestaEN(int id, MAETSGen.ApplicationCore.EN.MAETS.CestaEN cesta, MAETSGen.ApplicationCore.EN.MAETS.JuegoEN juego
                    )
{
        this.init (Id, cesta, juego);
}


public LineaCestaEN(LineaCestaEN lineaCesta)
{
        this.init (lineaCesta.Id, lineaCesta.Cesta, lineaCesta.Juego);
}

private void init (int id
                   , MAETSGen.ApplicationCore.EN.MAETS.CestaEN cesta, MAETSGen.ApplicationCore.EN.MAETS.JuegoEN juego)
{
        this.Id = id;


        this.Cesta = cesta;

        this.Juego = juego;
}

public override bool Equals (object obj)
{
        if (obj == null)
                return false;
        LineaCestaEN t = obj as LineaCestaEN;
        if (t == null)
                return false;
        if (Id.Equals (t.Id))
                return true;
        else
                return false;
}

public override int GetHashCode ()
{
        int hash = 13;

        hash += this.Id.GetHashCode ();
        return hash;
}
}
}
