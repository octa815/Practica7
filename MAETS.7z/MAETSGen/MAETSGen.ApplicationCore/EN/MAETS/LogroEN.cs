
using System;
// Definición clase LogroEN
namespace MAETSGen.ApplicationCore.EN.MAETS
{
public partial class LogroEN
{
/**
 *	Atributo id
 */
private int id;



/**
 *	Atributo cliente
 */
private System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.ClienteEN> cliente;



/**
 *	Atributo nombre
 */
private string nombre;



/**
 *	Atributo descrip
 */
private string descrip;






public virtual int Id {
        get { return id; } set { id = value;  }
}



public virtual System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.ClienteEN> Cliente {
        get { return cliente; } set { cliente = value;  }
}



public virtual string Nombre {
        get { return nombre; } set { nombre = value;  }
}



public virtual string Descrip {
        get { return descrip; } set { descrip = value;  }
}





public LogroEN()
{
        Cliente = new System.Collections.Generic.List<MAETSGen.ApplicationCore.EN.MAETS.ClienteEN>();
}



public LogroEN(int id, System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.ClienteEN> cliente, string nombre, string descrip
               )
{
        this.init (Id, cliente, nombre, descrip);
}


public LogroEN(LogroEN logro)
{
        this.init (logro.Id, logro.Cliente, logro.Nombre, logro.Descrip);
}

private void init (int id
                   , System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.ClienteEN> cliente, string nombre, string descrip)
{
        this.Id = id;


        this.Cliente = cliente;

        this.Nombre = nombre;

        this.Descrip = descrip;
}

public override bool Equals (object obj)
{
        if (obj == null)
                return false;
        LogroEN t = obj as LogroEN;
        if (t == null)
                return false;
        if (Id.Equals (t.Id))
                return true;
        else
                return false;
}

public override int GetHashCode ()
{
        int hash = 13;

        hash += this.Id.GetHashCode ();
        return hash;
}
}
}
