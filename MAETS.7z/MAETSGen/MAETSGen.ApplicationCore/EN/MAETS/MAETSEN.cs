
using System;
// Definición clase MAETSEN
namespace MAETSGen.ApplicationCore.EN.MAETS
{
public partial class MAETSEN
{
/**
 *	Atributo id
 */
private int id;



/**
 *	Atributo juegos
 */
private System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.JuegoEN> juegos;






public virtual int Id {
        get { return id; } set { id = value;  }
}



public virtual System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.JuegoEN> Juegos {
        get { return juegos; } set { juegos = value;  }
}





public MAETSEN()
{
        juegos = new System.Collections.Generic.List<MAETSGen.ApplicationCore.EN.MAETS.JuegoEN>();
}



public MAETSEN(int id, System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.JuegoEN> juegos
               )
{
        this.init (Id, juegos);
}


public MAETSEN(MAETSEN mAETS)
{
        this.init (mAETS.Id, mAETS.Juegos);
}

private void init (int id
                   , System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.JuegoEN> juegos)
{
        this.Id = id;


        this.Juegos = juegos;
}

public override bool Equals (object obj)
{
        if (obj == null)
                return false;
        MAETSEN t = obj as MAETSEN;
        if (t == null)
                return false;
        if (Id.Equals (t.Id))
                return true;
        else
                return false;
}

public override int GetHashCode ()
{
        int hash = 13;

        hash += this.Id.GetHashCode ();
        return hash;
}
}
}
