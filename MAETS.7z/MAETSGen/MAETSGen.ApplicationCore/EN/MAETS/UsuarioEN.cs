
using System;
// Definición clase UsuarioEN
namespace MAETSGen.ApplicationCore.EN.MAETS
{
public partial class UsuarioEN                                                                      : MAETSGen.ApplicationCore.EN.MAETS.ClienteEN


{
/**
 *	Atributo nombre
 */
private string nombre;



/**
 *	Atributo email
 */
private string email;



/**
 *	Atributo consulta
 */
private System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.ConsultaEN> consulta;






public virtual string Nombre {
        get { return nombre; } set { nombre = value;  }
}



public virtual string Email {
        get { return email; } set { email = value;  }
}



public virtual System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.ConsultaEN> Consulta {
        get { return consulta; } set { consulta = value;  }
}





public UsuarioEN() : base ()
{
        consulta = new System.Collections.Generic.List<MAETSGen.ApplicationCore.EN.MAETS.ConsultaEN>();
}



public UsuarioEN(string dni, string nombre, string email, System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.ConsultaEN> consulta
                 , string pass, System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.CestaEN> cesta, System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.LogroEN> logro, MAETSGen.ApplicationCore.EN.MAETS.BibliotecaEN bibliotecas, System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.ComentariosEN> comentarioss, Nullable<DateTime> fechareg
                 )
{
        this.init (Dni, nombre, email, consulta, pass, cesta, logro, bibliotecas, comentarioss, fechareg);
}


public UsuarioEN(UsuarioEN usuario)
{
        this.init (usuario.Dni, usuario.Nombre, usuario.Email, usuario.Consulta, usuario.Pass, usuario.Cesta, usuario.Logro, usuario.Bibliotecas, usuario.Comentarioss, usuario.Fechareg);
}

private void init (string dni
                   , string nombre, string email, System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.ConsultaEN> consulta, string pass, System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.CestaEN> cesta, System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.LogroEN> logro, MAETSGen.ApplicationCore.EN.MAETS.BibliotecaEN bibliotecas, System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.ComentariosEN> comentarioss, Nullable<DateTime> fechareg)
{
        this.Dni = dni;


        this.Nombre = nombre;

        this.Email = email;

        this.Consulta = consulta;

        this.Pass = pass;

        this.Cesta = cesta;

        this.Logro = logro;

        this.Bibliotecas = bibliotecas;

        this.Comentarioss = comentarioss;

        this.Fechareg = fechareg;
}

public override bool Equals (object obj)
{
        if (obj == null)
                return false;
        UsuarioEN t = obj as UsuarioEN;
        if (t == null)
                return false;
        if (Dni.Equals (t.Dni))
                return true;
        else
                return false;
}

public override int GetHashCode ()
{
        int hash = 13;

        hash += this.Dni.GetHashCode ();
        return hash;
}
}
}
