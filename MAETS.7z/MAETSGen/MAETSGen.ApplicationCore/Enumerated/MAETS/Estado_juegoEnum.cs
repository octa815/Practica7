
using System;

namespace MAETSGen.ApplicationCore.Enumerated.MAETS
{
public enum Estado_juegoEnum { en_curso=1, agotado=2, adquirido=3, notiene=4 };
}
