
using System;

namespace MAETSGen.ApplicationCore.Enumerated.MAETS
{
public enum Tipo_PlanEnum { basico=1, personalizado=2, adquisicion=3 };
}
