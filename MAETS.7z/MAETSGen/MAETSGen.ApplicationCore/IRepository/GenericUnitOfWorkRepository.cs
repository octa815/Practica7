
using System;
using System.Collections.Generic;
using System.Text;

namespace MAETSGen.ApplicationCore.IRepository.MAETS
{
public abstract class GenericUnitOfWorkRepository
{
protected IClienteRepository clienterepository;
protected IAdministradorRepository administradorrepository;
protected IJuegoRepository juegorepository;
protected ICestaRepository cestarepository;
protected IBibliotecaRepository bibliotecarepository;
protected ILogroRepository logrorepository;
protected ILineaCestaRepository lineacestarepository;
protected IMAETSRepository maetsrepository;
protected IConsultaRepository consultarepository;
protected IComentariosRepository comentariosrepository;
protected ICategoriasRepository categoriasrepository;
protected IUsuarioRepository usuariorepository;
protected IDistribuidoraRepository distribuidorarepository;
protected ICopiaRepository copiarepository;


public abstract IClienteRepository ClienteRepository {
        get;
}
public abstract IAdministradorRepository AdministradorRepository {
        get;
}
public abstract IJuegoRepository JuegoRepository {
        get;
}
public abstract ICestaRepository CestaRepository {
        get;
}
public abstract IBibliotecaRepository BibliotecaRepository {
        get;
}
public abstract ILogroRepository LogroRepository {
        get;
}
public abstract ILineaCestaRepository LineaCestaRepository {
        get;
}
public abstract IMAETSRepository MAETSRepository {
        get;
}
public abstract IConsultaRepository ConsultaRepository {
        get;
}
public abstract IComentariosRepository ComentariosRepository {
        get;
}
public abstract ICategoriasRepository CategoriasRepository {
        get;
}
public abstract IUsuarioRepository UsuarioRepository {
        get;
}
public abstract IDistribuidoraRepository DistribuidoraRepository {
        get;
}
public abstract ICopiaRepository CopiaRepository {
        get;
}
}
}
