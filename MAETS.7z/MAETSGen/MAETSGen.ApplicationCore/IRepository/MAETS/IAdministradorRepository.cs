
using System;
using MAETSGen.ApplicationCore.EN.MAETS;
using MAETSGen.ApplicationCore.CP.MAETS;

namespace MAETSGen.ApplicationCore.IRepository.MAETS
{
public partial interface IAdministradorRepository
{
void setSessionCP (GenericSessionCP session);

AdministradorEN ReadOIDDefault (string dni
                                );

void ModifyDefault (AdministradorEN administrador);

System.Collections.Generic.IList<AdministradorEN> ReadAllDefault (int first, int size);



string Nuevo (AdministradorEN administrador);

System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.AdministradorEN> DameAdminporUsu (string n_usu);
}
}
