
using System;
using MAETSGen.ApplicationCore.EN.MAETS;
using MAETSGen.ApplicationCore.CP.MAETS;

namespace MAETSGen.ApplicationCore.IRepository.MAETS
{
public partial interface IBibliotecaRepository
{
void setSessionCP (GenericSessionCP session);

BibliotecaEN ReadOIDDefault (int id
                             );

void ModifyDefault (BibliotecaEN biblioteca);

System.Collections.Generic.IList<BibliotecaEN> ReadAllDefault (int first, int size);



int Nuevo (BibliotecaEN biblioteca);

void Modificar (BibliotecaEN biblioteca);


void Borrar (int id
             );


BibliotecaEN LeeID (int id
                    );


System.Collections.Generic.IList<BibliotecaEN> LeeTodos (int first, int size);
}
}
