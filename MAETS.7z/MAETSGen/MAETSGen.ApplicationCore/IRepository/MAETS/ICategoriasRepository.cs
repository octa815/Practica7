
using System;
using MAETSGen.ApplicationCore.EN.MAETS;
using MAETSGen.ApplicationCore.CP.MAETS;

namespace MAETSGen.ApplicationCore.IRepository.MAETS
{
public partial interface ICategoriasRepository
{
void setSessionCP (GenericSessionCP session);

CategoriasEN ReadOIDDefault (string cat
                             );

void ModifyDefault (CategoriasEN categorias);

System.Collections.Generic.IList<CategoriasEN> ReadAllDefault (int first, int size);



string Nuevo (CategoriasEN categorias);

void Modificar (CategoriasEN categorias);


void Borrar (string cat
             );
}
}
