
using System;
using MAETSGen.ApplicationCore.EN.MAETS;
using MAETSGen.ApplicationCore.CP.MAETS;

namespace MAETSGen.ApplicationCore.IRepository.MAETS
{
public partial interface ICestaRepository
{
void setSessionCP (GenericSessionCP session);

CestaEN ReadOIDDefault (int id_pedido
                        );

void ModifyDefault (CestaEN cesta);

System.Collections.Generic.IList<CestaEN> ReadAllDefault (int first, int size);



int Nuevo (CestaEN cesta);

void Modificar (CestaEN cesta);


void Borrar (int id_pedido
             );


CestaEN LeeID (int id_pedido
               );


System.Collections.Generic.IList<CestaEN> LeeTodos (int first, int size);



System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.CestaEN> DameCestaJuego (string c_juego);


System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.CestaEN> DameTipoPlan (MAETSGen.ApplicationCore.Enumerated.MAETS.Tipo_PlanEnum ? plan);
}
}
