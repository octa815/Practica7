
using System;
using MAETSGen.ApplicationCore.EN.MAETS;
using MAETSGen.ApplicationCore.CP.MAETS;

namespace MAETSGen.ApplicationCore.IRepository.MAETS
{
public partial interface IComentariosRepository
{
void setSessionCP (GenericSessionCP session);

ComentariosEN ReadOIDDefault (int id
                              );

void ModifyDefault (ComentariosEN comentarios);

System.Collections.Generic.IList<ComentariosEN> ReadAllDefault (int first, int size);



int Nuevo (ComentariosEN comentarios);

void Modificar (ComentariosEN comentarios);


void Borrar (int id
             );
}
}
