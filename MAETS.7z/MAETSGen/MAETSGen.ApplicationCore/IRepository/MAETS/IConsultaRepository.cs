
using System;
using MAETSGen.ApplicationCore.EN.MAETS;
using MAETSGen.ApplicationCore.CP.MAETS;

namespace MAETSGen.ApplicationCore.IRepository.MAETS
{
public partial interface IConsultaRepository
{
void setSessionCP (GenericSessionCP session);

ConsultaEN ReadOIDDefault (int IDconsulta
                           );

void ModifyDefault (ConsultaEN consulta);

System.Collections.Generic.IList<ConsultaEN> ReadAllDefault (int first, int size);



int Nuevo (ConsultaEN consulta);

void Modificar (ConsultaEN consulta);


void Borrar (int IDconsulta
             );


ConsultaEN LeeID (int IDconsulta
                  );


System.Collections.Generic.IList<ConsultaEN> LeeTodos (int first, int size);
}
}
