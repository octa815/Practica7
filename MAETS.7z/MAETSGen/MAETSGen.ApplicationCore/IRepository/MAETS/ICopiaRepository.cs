
using System;
using MAETSGen.ApplicationCore.EN.MAETS;
using MAETSGen.ApplicationCore.CP.MAETS;

namespace MAETSGen.ApplicationCore.IRepository.MAETS
{
public partial interface ICopiaRepository
{
void setSessionCP (GenericSessionCP session);

CopiaEN ReadOIDDefault (int num_copia
                        );

void ModifyDefault (CopiaEN copia);

System.Collections.Generic.IList<CopiaEN> ReadAllDefault (int first, int size);



int Nuevo (CopiaEN copia);

void Modificar (CopiaEN copia);


void Borrar (int num_copia
             );


CopiaEN LeeID (int num_copia
               );


System.Collections.Generic.IList<CopiaEN> LeeTodos (int first, int size);


System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.CopiaEN> DameCopias (string n_game);



System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.CopiaEN> DameEstadoJuego (MAETSGen.ApplicationCore.Enumerated.MAETS.Estado_juegoEnum ? estad);
}
}
