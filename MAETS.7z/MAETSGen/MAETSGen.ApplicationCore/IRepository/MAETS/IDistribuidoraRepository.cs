
using System;
using MAETSGen.ApplicationCore.EN.MAETS;
using MAETSGen.ApplicationCore.CP.MAETS;

namespace MAETSGen.ApplicationCore.IRepository.MAETS
{
public partial interface IDistribuidoraRepository
{
void setSessionCP (GenericSessionCP session);

DistribuidoraEN ReadOIDDefault (int ID_distrib
                                );

void ModifyDefault (DistribuidoraEN distribuidora);

System.Collections.Generic.IList<DistribuidoraEN> ReadAllDefault (int first, int size);



int Nuevo (DistribuidoraEN distribuidora);

void Modificar (DistribuidoraEN distribuidora);


void Borrar (int ID_distrib
             );
}
}
