
using System;
using MAETSGen.ApplicationCore.EN.MAETS;
using MAETSGen.ApplicationCore.CP.MAETS;

namespace MAETSGen.ApplicationCore.IRepository.MAETS
{
public partial interface IJuegoRepository
{
void setSessionCP (GenericSessionCP session);

JuegoEN ReadOIDDefault (string nombre
                        );

void ModifyDefault (JuegoEN juego);

System.Collections.Generic.IList<JuegoEN> ReadAllDefault (int first, int size);



string Nuevo (JuegoEN juego);

void Modificar (JuegoEN juego);


void Borrar (string nombre
             );


JuegoEN LeeID (string nombre
               );


System.Collections.Generic.IList<JuegoEN> LeeTodos (int first, int size);


System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.JuegoEN> DameJuegoporCat (string cat_game);
}
}
