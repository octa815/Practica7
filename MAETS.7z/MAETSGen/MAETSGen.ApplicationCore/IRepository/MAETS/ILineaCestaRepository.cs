
using System;
using MAETSGen.ApplicationCore.EN.MAETS;
using MAETSGen.ApplicationCore.CP.MAETS;

namespace MAETSGen.ApplicationCore.IRepository.MAETS
{
public partial interface ILineaCestaRepository
{
void setSessionCP (GenericSessionCP session);

LineaCestaEN ReadOIDDefault (int id
                             );

void ModifyDefault (LineaCestaEN lineaCesta);

System.Collections.Generic.IList<LineaCestaEN> ReadAllDefault (int first, int size);



int Nuevo (LineaCestaEN lineaCesta);

void Modificar (LineaCestaEN lineaCesta);


void Borrar (int id
             );
}
}
