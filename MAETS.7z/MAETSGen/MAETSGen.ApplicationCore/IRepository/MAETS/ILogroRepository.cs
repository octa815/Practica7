
using System;
using MAETSGen.ApplicationCore.EN.MAETS;
using MAETSGen.ApplicationCore.CP.MAETS;

namespace MAETSGen.ApplicationCore.IRepository.MAETS
{
public partial interface ILogroRepository
{
void setSessionCP (GenericSessionCP session);

LogroEN ReadOIDDefault (int id
                        );

void ModifyDefault (LogroEN logro);

System.Collections.Generic.IList<LogroEN> ReadAllDefault (int first, int size);



int Nuevo (LogroEN logro);

void Modificar (LogroEN logro);


void Borrar (int id
             );


LogroEN LeeID (int id
               );


System.Collections.Generic.IList<LogroEN> LeeTodos (int first, int size);
}
}
