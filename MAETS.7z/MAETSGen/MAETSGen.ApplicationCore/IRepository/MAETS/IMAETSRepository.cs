
using System;
using MAETSGen.ApplicationCore.EN.MAETS;
using MAETSGen.ApplicationCore.CP.MAETS;

namespace MAETSGen.ApplicationCore.IRepository.MAETS
{
public partial interface IMAETSRepository
{
void setSessionCP (GenericSessionCP session);

MAETSEN ReadOIDDefault (int id
                        );

void ModifyDefault (MAETSEN mAETS);

System.Collections.Generic.IList<MAETSEN> ReadAllDefault (int first, int size);



int Nuevo (MAETSEN mAETS);

void Modificar (MAETSEN mAETS);


void Borrar (int id
             );
}
}
