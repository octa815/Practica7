
using System;
using MAETSGen.ApplicationCore.EN.MAETS;
using MAETSGen.ApplicationCore.CP.MAETS;

namespace MAETSGen.ApplicationCore.IRepository.MAETS
{
public partial interface IUsuarioRepository
{
void setSessionCP (GenericSessionCP session);

UsuarioEN ReadOIDDefault (string dni
                          );

void ModifyDefault (UsuarioEN usuario);

System.Collections.Generic.IList<UsuarioEN> ReadAllDefault (int first, int size);



string Nuevo (UsuarioEN usuario);

void Modificar (UsuarioEN usuario);


void Borrar (string dni
             );




UsuarioEN LeeID (string dni
                 );


System.Collections.Generic.IList<UsuarioEN> LeeTodos (int first, int size);


System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.UsuarioEN> DameEmail (string usu);
}
}
