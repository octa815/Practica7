
using System;
using MAETSGen.ApplicationCore.EN.MAETS;
namespace MAETSGen.Infraestructure.EN.MAETS
{
public partial class AdministradorNH : AdministradorEN {
public AdministradorNH ()
{
}

public AdministradorNH (AdministradorEN dto) : base (dto)
{
}
}
}
