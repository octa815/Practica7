
using System;
using MAETSGen.ApplicationCore.EN.MAETS;
namespace MAETSGen.Infraestructure.EN.MAETS
{
public partial class CategoriasNH : CategoriasEN {
public CategoriasNH ()
{
}

public CategoriasNH (CategoriasEN dto) : base (dto)
{
}
}
}
