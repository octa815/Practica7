
using System;
using MAETSGen.ApplicationCore.EN.MAETS;
namespace MAETSGen.Infraestructure.EN.MAETS
{
public partial class ComentariosNH : ComentariosEN {
public ComentariosNH ()
{
}

public ComentariosNH (ComentariosEN dto) : base (dto)
{
}
}
}
