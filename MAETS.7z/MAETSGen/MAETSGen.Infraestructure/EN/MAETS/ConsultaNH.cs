
using System;
using MAETSGen.ApplicationCore.EN.MAETS;
namespace MAETSGen.Infraestructure.EN.MAETS
{
public partial class ConsultaNH : ConsultaEN {
public ConsultaNH ()
{
}

public ConsultaNH (ConsultaEN dto) : base (dto)
{
}
}
}
