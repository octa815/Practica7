
using System;
using MAETSGen.ApplicationCore.EN.MAETS;
namespace MAETSGen.Infraestructure.EN.MAETS
{
public partial class CopiaNH : CopiaEN {
public CopiaNH ()
{
}

public CopiaNH (CopiaEN dto) : base (dto)
{
}
}
}
