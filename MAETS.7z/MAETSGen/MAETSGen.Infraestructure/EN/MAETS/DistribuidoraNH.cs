
using System;
using MAETSGen.ApplicationCore.EN.MAETS;
namespace MAETSGen.Infraestructure.EN.MAETS
{
public partial class DistribuidoraNH : DistribuidoraEN {
public DistribuidoraNH ()
{
}

public DistribuidoraNH (DistribuidoraEN dto) : base (dto)
{
}
}
}
