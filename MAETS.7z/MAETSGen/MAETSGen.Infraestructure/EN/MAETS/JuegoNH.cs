
using System;
using MAETSGen.ApplicationCore.EN.MAETS;
namespace MAETSGen.Infraestructure.EN.MAETS
{
public partial class JuegoNH : JuegoEN {
public JuegoNH ()
{
}

public JuegoNH (JuegoEN dto) : base (dto)
{
}
}
}
