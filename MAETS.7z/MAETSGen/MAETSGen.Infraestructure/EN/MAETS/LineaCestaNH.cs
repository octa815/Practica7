
using System;
using MAETSGen.ApplicationCore.EN.MAETS;
namespace MAETSGen.Infraestructure.EN.MAETS
{
public partial class LineaCestaNH : LineaCestaEN {
public LineaCestaNH ()
{
}

public LineaCestaNH (LineaCestaEN dto) : base (dto)
{
}
}
}
