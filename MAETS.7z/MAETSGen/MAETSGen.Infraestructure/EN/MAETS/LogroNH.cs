
using System;
using MAETSGen.ApplicationCore.EN.MAETS;
namespace MAETSGen.Infraestructure.EN.MAETS
{
public partial class LogroNH : LogroEN {
public LogroNH ()
{
}

public LogroNH (LogroEN dto) : base (dto)
{
}
}
}
