
using System;
using MAETSGen.ApplicationCore.EN.MAETS;
namespace MAETSGen.Infraestructure.EN.MAETS
{
public partial class MAETSNH : MAETSEN {
public MAETSNH ()
{
}

public MAETSNH (MAETSEN dto) : base (dto)
{
}
}
}
