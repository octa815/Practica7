
using System;
using System.Text;
using MAETSGen.ApplicationCore.CEN.MAETS;
using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;
using MAETSGen.ApplicationCore.EN.MAETS;
using MAETSGen.ApplicationCore.Exceptions;
using MAETSGen.ApplicationCore.IRepository.MAETS;
using MAETSGen.ApplicationCore.CP.MAETS;
using MAETSGen.Infraestructure.EN.MAETS;


/*
 * Clase Biblioteca:
 *
 */

namespace MAETSGen.Infraestructure.Repository.MAETS
{
public partial class BibliotecaRepository : BasicRepository, IBibliotecaRepository
{
public BibliotecaRepository() : base ()
{
}


public BibliotecaRepository(GenericSessionCP sessionAux) : base (sessionAux)
{
}


public void setSessionCP (GenericSessionCP session)
{
        sessionInside = false;
        this.session = (ISession)session.CurrentSession;
}


public BibliotecaEN ReadOIDDefault (int id
                                    )
{
        BibliotecaEN bibliotecaEN = null;

        try
        {
                SessionInitializeTransaction ();
                bibliotecaEN = (BibliotecaEN)session.Get (typeof(BibliotecaNH), id);
                SessionCommit ();
        }

        catch (Exception) {
        }


        finally
        {
                SessionClose ();
        }

        return bibliotecaEN;
}

public System.Collections.Generic.IList<BibliotecaEN> ReadAllDefault (int first, int size)
{
        System.Collections.Generic.IList<BibliotecaEN> result = null;
        try
        {
                using (ITransaction tx = session.BeginTransaction ())
                {
                        if (size > 0)
                                result = session.CreateCriteria (typeof(BibliotecaNH)).
                                         SetFirstResult (first).SetMaxResults (size).List<BibliotecaEN>();
                        else
                                result = session.CreateCriteria (typeof(BibliotecaNH)).List<BibliotecaEN>();
                }
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in BibliotecaRepository.", ex);
        }

        return result;
}

// Modify default (Update all attributes of the class)

public void ModifyDefault (BibliotecaEN biblioteca)
{
        try
        {
                SessionInitializeTransaction ();
                BibliotecaNH bibliotecaNH = (BibliotecaNH)session.Load (typeof(BibliotecaNH), biblioteca.Id);


                session.Update (bibliotecaNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in BibliotecaRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }
}


public int Nuevo (BibliotecaEN biblioteca)
{
        BibliotecaNH bibliotecaNH = new BibliotecaNH (biblioteca);

        try
        {
                SessionInitializeTransaction ();
                if (biblioteca.Cliente != null) {
                        // Argumento OID y no colección.
                        bibliotecaNH
                        .Cliente = (MAETSGen.ApplicationCore.EN.MAETS.ClienteEN)session.Load (typeof(MAETSGen.ApplicationCore.EN.MAETS.ClienteEN), biblioteca.Cliente.Dni);

                        bibliotecaNH.Cliente.Bibliotecas
                                = bibliotecaNH;
                }

                session.Save (bibliotecaNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in BibliotecaRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }

        return bibliotecaNH.Id;
}

public void Modificar (BibliotecaEN biblioteca)
{
        try
        {
                SessionInitializeTransaction ();
                BibliotecaNH bibliotecaNH = (BibliotecaNH)session.Load (typeof(BibliotecaNH), biblioteca.Id);
                session.Update (bibliotecaNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in BibliotecaRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }
}
public void Borrar (int id
                    )
{
        try
        {
                SessionInitializeTransaction ();
                BibliotecaNH bibliotecaNH = (BibliotecaNH)session.Load (typeof(BibliotecaNH), id);
                session.Delete (bibliotecaNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in BibliotecaRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }
}

//Sin e: LeeID
//Con e: BibliotecaEN
public BibliotecaEN LeeID (int id
                           )
{
        BibliotecaEN bibliotecaEN = null;

        try
        {
                SessionInitializeTransaction ();
                bibliotecaEN = (BibliotecaEN)session.Get (typeof(BibliotecaNH), id);
                SessionCommit ();
        }

        catch (Exception) {
        }


        finally
        {
                SessionClose ();
        }

        return bibliotecaEN;
}

public System.Collections.Generic.IList<BibliotecaEN> LeeTodos (int first, int size)
{
        System.Collections.Generic.IList<BibliotecaEN> result = null;
        try
        {
                SessionInitializeTransaction ();
                if (size > 0)
                        result = session.CreateCriteria (typeof(BibliotecaNH)).
                                 SetFirstResult (first).SetMaxResults (size).List<BibliotecaEN>();
                else
                        result = session.CreateCriteria (typeof(BibliotecaNH)).List<BibliotecaEN>();
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in BibliotecaRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }

        return result;
}
}
}
