
using System;
using System.Text;
using MAETSGen.ApplicationCore.CEN.MAETS;
using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;
using MAETSGen.ApplicationCore.EN.MAETS;
using MAETSGen.ApplicationCore.Exceptions;
using MAETSGen.ApplicationCore.IRepository.MAETS;
using MAETSGen.ApplicationCore.CP.MAETS;
using MAETSGen.Infraestructure.EN.MAETS;


/*
 * Clase Categorias:
 *
 */

namespace MAETSGen.Infraestructure.Repository.MAETS
{
public partial class CategoriasRepository : BasicRepository, ICategoriasRepository
{
public CategoriasRepository() : base ()
{
}


public CategoriasRepository(GenericSessionCP sessionAux) : base (sessionAux)
{
}


public void setSessionCP (GenericSessionCP session)
{
        sessionInside = false;
        this.session = (ISession)session.CurrentSession;
}


public CategoriasEN ReadOIDDefault (string cat
                                    )
{
        CategoriasEN categoriasEN = null;

        try
        {
                SessionInitializeTransaction ();
                categoriasEN = (CategoriasEN)session.Get (typeof(CategoriasNH), cat);
                SessionCommit ();
        }

        catch (Exception) {
        }


        finally
        {
                SessionClose ();
        }

        return categoriasEN;
}

public System.Collections.Generic.IList<CategoriasEN> ReadAllDefault (int first, int size)
{
        System.Collections.Generic.IList<CategoriasEN> result = null;
        try
        {
                using (ITransaction tx = session.BeginTransaction ())
                {
                        if (size > 0)
                                result = session.CreateCriteria (typeof(CategoriasNH)).
                                         SetFirstResult (first).SetMaxResults (size).List<CategoriasEN>();
                        else
                                result = session.CreateCriteria (typeof(CategoriasNH)).List<CategoriasEN>();
                }
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in CategoriasRepository.", ex);
        }

        return result;
}

// Modify default (Update all attributes of the class)

public void ModifyDefault (CategoriasEN categorias)
{
        try
        {
                SessionInitializeTransaction ();
                CategoriasNH categoriasNH = (CategoriasNH)session.Load (typeof(CategoriasNH), categorias.Cat);



                session.Update (categoriasNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in CategoriasRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }
}


public string Nuevo (CategoriasEN categorias)
{
        CategoriasNH categoriasNH = new CategoriasNH (categorias);

        try
        {
                SessionInitializeTransaction ();

                session.Save (categoriasNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in CategoriasRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }

        return categoriasNH.Cat;
}

public void Modificar (CategoriasEN categorias)
{
        try
        {
                SessionInitializeTransaction ();
                CategoriasNH categoriasNH = (CategoriasNH)session.Load (typeof(CategoriasNH), categorias.Cat);
                session.Update (categoriasNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in CategoriasRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }
}
public void Borrar (string cat
                    )
{
        try
        {
                SessionInitializeTransaction ();
                CategoriasNH categoriasNH = (CategoriasNH)session.Load (typeof(CategoriasNH), cat);
                session.Delete (categoriasNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in CategoriasRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }
}
}
}
