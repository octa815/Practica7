
using System;
using System.Text;
using MAETSGen.ApplicationCore.CEN.MAETS;
using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;
using MAETSGen.ApplicationCore.EN.MAETS;
using MAETSGen.ApplicationCore.Exceptions;
using MAETSGen.ApplicationCore.IRepository.MAETS;
using MAETSGen.ApplicationCore.CP.MAETS;
using MAETSGen.Infraestructure.EN.MAETS;


/*
 * Clase Cesta:
 *
 */

namespace MAETSGen.Infraestructure.Repository.MAETS
{
public partial class CestaRepository : BasicRepository, ICestaRepository
{
public CestaRepository() : base ()
{
}


public CestaRepository(GenericSessionCP sessionAux) : base (sessionAux)
{
}


public void setSessionCP (GenericSessionCP session)
{
        sessionInside = false;
        this.session = (ISession)session.CurrentSession;
}


public CestaEN ReadOIDDefault (int id_pedido
                               )
{
        CestaEN cestaEN = null;

        try
        {
                SessionInitializeTransaction ();
                cestaEN = (CestaEN)session.Get (typeof(CestaNH), id_pedido);
                SessionCommit ();
        }

        catch (Exception) {
        }


        finally
        {
                SessionClose ();
        }

        return cestaEN;
}

public System.Collections.Generic.IList<CestaEN> ReadAllDefault (int first, int size)
{
        System.Collections.Generic.IList<CestaEN> result = null;
        try
        {
                using (ITransaction tx = session.BeginTransaction ())
                {
                        if (size > 0)
                                result = session.CreateCriteria (typeof(CestaNH)).
                                         SetFirstResult (first).SetMaxResults (size).List<CestaEN>();
                        else
                                result = session.CreateCriteria (typeof(CestaNH)).List<CestaEN>();
                }
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in CestaRepository.", ex);
        }

        return result;
}

// Modify default (Update all attributes of the class)

public void ModifyDefault (CestaEN cesta)
{
        try
        {
                SessionInitializeTransaction ();
                CestaNH cestaNH = (CestaNH)session.Load (typeof(CestaNH), cesta.Id_pedido);


                cestaNH.Fecha_add = cesta.Fecha_add;


                cestaNH.Estado = cesta.Estado;



                cestaNH.Plan_alq = cesta.Plan_alq;

                session.Update (cestaNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in CestaRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }
}


public int Nuevo (CestaEN cesta)
{
        CestaNH cestaNH = new CestaNH (cesta);

        try
        {
                SessionInitializeTransaction ();
                if (cesta.Cliente != null) {
                        // Argumento OID y no colección.
                        cestaNH
                        .Cliente = (MAETSGen.ApplicationCore.EN.MAETS.ClienteEN)session.Load (typeof(MAETSGen.ApplicationCore.EN.MAETS.ClienteEN), cesta.Cliente.Dni);

                        cestaNH.Cliente.Cesta
                        .Add (cestaNH);
                }

                session.Save (cestaNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in CestaRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }

        return cestaNH.Id_pedido;
}

public void Modificar (CestaEN cesta)
{
        try
        {
                SessionInitializeTransaction ();
                CestaNH cestaNH = (CestaNH)session.Load (typeof(CestaNH), cesta.Id_pedido);

                cestaNH.Fecha_add = cesta.Fecha_add;


                cestaNH.Estado = cesta.Estado;


                cestaNH.Plan_alq = cesta.Plan_alq;

                session.Update (cestaNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in CestaRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }
}
public void Borrar (int id_pedido
                    )
{
        try
        {
                SessionInitializeTransaction ();
                CestaNH cestaNH = (CestaNH)session.Load (typeof(CestaNH), id_pedido);
                session.Delete (cestaNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in CestaRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }
}

//Sin e: LeeID
//Con e: CestaEN
public CestaEN LeeID (int id_pedido
                      )
{
        CestaEN cestaEN = null;

        try
        {
                SessionInitializeTransaction ();
                cestaEN = (CestaEN)session.Get (typeof(CestaNH), id_pedido);
                SessionCommit ();
        }

        catch (Exception) {
        }


        finally
        {
                SessionClose ();
        }

        return cestaEN;
}

public System.Collections.Generic.IList<CestaEN> LeeTodos (int first, int size)
{
        System.Collections.Generic.IList<CestaEN> result = null;
        try
        {
                SessionInitializeTransaction ();
                if (size > 0)
                        result = session.CreateCriteria (typeof(CestaNH)).
                                 SetFirstResult (first).SetMaxResults (size).List<CestaEN>();
                else
                        result = session.CreateCriteria (typeof(CestaNH)).List<CestaEN>();
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in CestaRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }

        return result;
}

public System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.CestaEN> DameCestaJuego (string c_juego)
{
        System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.CestaEN> result;
        try
        {
                SessionInitializeTransaction ();
                //String sql = @"FROM CestaNH self where select cesta FROM CestaNH as cesta inner join cesta.LineasCesta as linea where linea.Juego.Nombre =:c_juego";
                //IQuery query = session.CreateQuery(sql);
                IQuery query = (IQuery)session.GetNamedQuery ("CestaNHdameCestaJuegoHQL");
                query.SetParameter ("c_juego", c_juego);

                result = query.List<MAETSGen.ApplicationCore.EN.MAETS.CestaEN>();
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in CestaRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }

        return result;
}
public System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.CestaEN> DameTipoPlan (MAETSGen.ApplicationCore.Enumerated.MAETS.Tipo_PlanEnum ? plan)
{
        System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.CestaEN> result;
        try
        {
                SessionInitializeTransaction ();
                //String sql = @"FROM CestaNH self where select cest FROM CestaNH as cest where cest.Plan_alq =:plan";
                //IQuery query = session.CreateQuery(sql);
                IQuery query = (IQuery)session.GetNamedQuery ("CestaNHdameTipoPlanHQL");
                query.SetParameter ("plan", plan);

                result = query.List<MAETSGen.ApplicationCore.EN.MAETS.CestaEN>();
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in CestaRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }

        return result;
}
}
}
