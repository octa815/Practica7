
using System;
using System.Text;
using MAETSGen.ApplicationCore.CEN.MAETS;
using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;
using MAETSGen.ApplicationCore.EN.MAETS;
using MAETSGen.ApplicationCore.Exceptions;
using MAETSGen.ApplicationCore.IRepository.MAETS;
using MAETSGen.ApplicationCore.CP.MAETS;
using MAETSGen.Infraestructure.EN.MAETS;


/*
 * Clase Cliente:
 *
 */

namespace MAETSGen.Infraestructure.Repository.MAETS
{
public partial class ClienteRepository : BasicRepository, IClienteRepository
{
public ClienteRepository() : base ()
{
}


public ClienteRepository(GenericSessionCP sessionAux) : base (sessionAux)
{
}


public void setSessionCP (GenericSessionCP session)
{
        sessionInside = false;
        this.session = (ISession)session.CurrentSession;
}


public ClienteEN ReadOIDDefault (string dni
                                 )
{
        ClienteEN clienteEN = null;

        try
        {
                SessionInitializeTransaction ();
                clienteEN = (ClienteEN)session.Get (typeof(ClienteNH), dni);
                SessionCommit ();
        }

        catch (Exception) {
        }


        finally
        {
                SessionClose ();
        }

        return clienteEN;
}

public System.Collections.Generic.IList<ClienteEN> ReadAllDefault (int first, int size)
{
        System.Collections.Generic.IList<ClienteEN> result = null;
        try
        {
                using (ITransaction tx = session.BeginTransaction ())
                {
                        if (size > 0)
                                result = session.CreateCriteria (typeof(ClienteNH)).
                                         SetFirstResult (first).SetMaxResults (size).List<ClienteEN>();
                        else
                                result = session.CreateCriteria (typeof(ClienteNH)).List<ClienteEN>();
                }
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in ClienteRepository.", ex);
        }

        return result;
}

// Modify default (Update all attributes of the class)

public void ModifyDefault (ClienteEN cliente)
{
        try
        {
                SessionInitializeTransaction ();
                ClienteNH clienteNH = (ClienteNH)session.Load (typeof(ClienteNH), cliente.Dni);

                clienteNH.Pass = cliente.Pass;






                clienteNH.Fechareg = cliente.Fechareg;

                session.Update (clienteNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in ClienteRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }
}


public string Nuevo (ClienteEN cliente)
{
        ClienteNH clienteNH = new ClienteNH (cliente);

        try
        {
                SessionInitializeTransaction ();

                session.Save (clienteNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in ClienteRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }

        return clienteNH.Dni;
}

public void Modificar (ClienteEN cliente)
{
        try
        {
                SessionInitializeTransaction ();
                ClienteNH clienteNH = (ClienteNH)session.Load (typeof(ClienteNH), cliente.Dni);

                clienteNH.Pass = cliente.Pass;


                clienteNH.Fechareg = cliente.Fechareg;

                session.Update (clienteNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in ClienteRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }
}
public void Borrar (string dni
                    )
{
        try
        {
                SessionInitializeTransaction ();
                ClienteNH clienteNH = (ClienteNH)session.Load (typeof(ClienteNH), dni);
                session.Delete (clienteNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in ClienteRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }
}

//Sin e: LeeID
//Con e: ClienteEN
public ClienteEN LeeID (string dni
                        )
{
        ClienteEN clienteEN = null;

        try
        {
                SessionInitializeTransaction ();
                clienteEN = (ClienteEN)session.Get (typeof(ClienteNH), dni);
                SessionCommit ();
        }

        catch (Exception) {
        }


        finally
        {
                SessionClose ();
        }

        return clienteEN;
}

public System.Collections.Generic.IList<ClienteEN> LeeTodos (int first, int size)
{
        System.Collections.Generic.IList<ClienteEN> result = null;
        try
        {
                SessionInitializeTransaction ();
                if (size > 0)
                        result = session.CreateCriteria (typeof(ClienteNH)).
                                 SetFirstResult (first).SetMaxResults (size).List<ClienteEN>();
                else
                        result = session.CreateCriteria (typeof(ClienteNH)).List<ClienteEN>();
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in ClienteRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }

        return result;
}

public System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.ClienteEN> DameClientesJuego (string cc_juego)
{
        System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.ClienteEN> result;
        try
        {
                SessionInitializeTransaction ();
                //String sql = @"FROM ClienteNH self where select cliente FROM ClienteNH as cliente inner join cliente.Comentarioss as com where com.Juego.Nombre =:cc_juego";
                //IQuery query = session.CreateQuery(sql);
                IQuery query = (IQuery)session.GetNamedQuery ("ClienteNHdameClientesJuegoHQL");
                query.SetParameter ("cc_juego", cc_juego);

                result = query.List<MAETSGen.ApplicationCore.EN.MAETS.ClienteEN>();
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in ClienteRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }

        return result;
}
public System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.ClienteEN> DamePassword (string cliente)
{
        System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.ClienteEN> result;
        try
        {
                SessionInitializeTransaction ();
                //String sql = @"FROM ClienteNH self where select cl FROM ClienteNH as cl where cl.Dni =:cliente";
                //IQuery query = session.CreateQuery(sql);
                IQuery query = (IQuery)session.GetNamedQuery ("ClienteNHDamePasswordHQL");
                query.SetParameter ("cliente", cliente);

                result = query.List<MAETSGen.ApplicationCore.EN.MAETS.ClienteEN>();
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in ClienteRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }

        return result;
}
}
}
