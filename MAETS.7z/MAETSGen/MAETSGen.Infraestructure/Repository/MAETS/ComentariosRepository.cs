
using System;
using System.Text;
using MAETSGen.ApplicationCore.CEN.MAETS;
using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;
using MAETSGen.ApplicationCore.EN.MAETS;
using MAETSGen.ApplicationCore.Exceptions;
using MAETSGen.ApplicationCore.IRepository.MAETS;
using MAETSGen.ApplicationCore.CP.MAETS;
using MAETSGen.Infraestructure.EN.MAETS;


/*
 * Clase Comentarios:
 *
 */

namespace MAETSGen.Infraestructure.Repository.MAETS
{
public partial class ComentariosRepository : BasicRepository, IComentariosRepository
{
public ComentariosRepository() : base ()
{
}


public ComentariosRepository(GenericSessionCP sessionAux) : base (sessionAux)
{
}


public void setSessionCP (GenericSessionCP session)
{
        sessionInside = false;
        this.session = (ISession)session.CurrentSession;
}


public ComentariosEN ReadOIDDefault (int id
                                     )
{
        ComentariosEN comentariosEN = null;

        try
        {
                SessionInitializeTransaction ();
                comentariosEN = (ComentariosEN)session.Get (typeof(ComentariosNH), id);
                SessionCommit ();
        }

        catch (Exception) {
        }


        finally
        {
                SessionClose ();
        }

        return comentariosEN;
}

public System.Collections.Generic.IList<ComentariosEN> ReadAllDefault (int first, int size)
{
        System.Collections.Generic.IList<ComentariosEN> result = null;
        try
        {
                using (ITransaction tx = session.BeginTransaction ())
                {
                        if (size > 0)
                                result = session.CreateCriteria (typeof(ComentariosNH)).
                                         SetFirstResult (first).SetMaxResults (size).List<ComentariosEN>();
                        else
                                result = session.CreateCriteria (typeof(ComentariosNH)).List<ComentariosEN>();
                }
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in ComentariosRepository.", ex);
        }

        return result;
}

// Modify default (Update all attributes of the class)

public void ModifyDefault (ComentariosEN comentarios)
{
        try
        {
                SessionInitializeTransaction ();
                ComentariosNH comentariosNH = (ComentariosNH)session.Load (typeof(ComentariosNH), comentarios.Id);



                comentariosNH.Texto = comentarios.Texto;

                session.Update (comentariosNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in ComentariosRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }
}


public int Nuevo (ComentariosEN comentarios)
{
        ComentariosNH comentariosNH = new ComentariosNH (comentarios);

        try
        {
                SessionInitializeTransaction ();
                if (comentarios.Cliente != null) {
                        // Argumento OID y no colección.
                        comentariosNH
                        .Cliente = (MAETSGen.ApplicationCore.EN.MAETS.ClienteEN)session.Load (typeof(MAETSGen.ApplicationCore.EN.MAETS.ClienteEN), comentarios.Cliente.Dni);

                        comentariosNH.Cliente.Comentarioss
                        .Add (comentariosNH);
                }
                if (comentarios.Juego != null) {
                        // Argumento OID y no colección.
                        comentariosNH
                        .Juego = (MAETSGen.ApplicationCore.EN.MAETS.JuegoEN)session.Load (typeof(MAETSGen.ApplicationCore.EN.MAETS.JuegoEN), comentarios.Juego.Nombre);

                        comentariosNH.Juego.Comentarios
                        .Add (comentariosNH);
                }

                session.Save (comentariosNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in ComentariosRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }

        return comentariosNH.Id;
}

public void Modificar (ComentariosEN comentarios)
{
        try
        {
                SessionInitializeTransaction ();
                ComentariosNH comentariosNH = (ComentariosNH)session.Load (typeof(ComentariosNH), comentarios.Id);

                comentariosNH.Texto = comentarios.Texto;

                session.Update (comentariosNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in ComentariosRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }
}
public void Borrar (int id
                    )
{
        try
        {
                SessionInitializeTransaction ();
                ComentariosNH comentariosNH = (ComentariosNH)session.Load (typeof(ComentariosNH), id);
                session.Delete (comentariosNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in ComentariosRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }
}
}
}
