
using System;
using System.Text;
using MAETSGen.ApplicationCore.CEN.MAETS;
using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;
using MAETSGen.ApplicationCore.EN.MAETS;
using MAETSGen.ApplicationCore.Exceptions;
using MAETSGen.ApplicationCore.IRepository.MAETS;
using MAETSGen.ApplicationCore.CP.MAETS;
using MAETSGen.Infraestructure.EN.MAETS;


/*
 * Clase Consulta:
 *
 */

namespace MAETSGen.Infraestructure.Repository.MAETS
{
public partial class ConsultaRepository : BasicRepository, IConsultaRepository
{
public ConsultaRepository() : base ()
{
}


public ConsultaRepository(GenericSessionCP sessionAux) : base (sessionAux)
{
}


public void setSessionCP (GenericSessionCP session)
{
        sessionInside = false;
        this.session = (ISession)session.CurrentSession;
}


public ConsultaEN ReadOIDDefault (int IDconsulta
                                  )
{
        ConsultaEN consultaEN = null;

        try
        {
                SessionInitializeTransaction ();
                consultaEN = (ConsultaEN)session.Get (typeof(ConsultaNH), IDconsulta);
                SessionCommit ();
        }

        catch (Exception) {
        }


        finally
        {
                SessionClose ();
        }

        return consultaEN;
}

public System.Collections.Generic.IList<ConsultaEN> ReadAllDefault (int first, int size)
{
        System.Collections.Generic.IList<ConsultaEN> result = null;
        try
        {
                using (ITransaction tx = session.BeginTransaction ())
                {
                        if (size > 0)
                                result = session.CreateCriteria (typeof(ConsultaNH)).
                                         SetFirstResult (first).SetMaxResults (size).List<ConsultaEN>();
                        else
                                result = session.CreateCriteria (typeof(ConsultaNH)).List<ConsultaEN>();
                }
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in ConsultaRepository.", ex);
        }

        return result;
}

// Modify default (Update all attributes of the class)

public void ModifyDefault (ConsultaEN consulta)
{
        try
        {
                SessionInitializeTransaction ();
                ConsultaNH consultaNH = (ConsultaNH)session.Load (typeof(ConsultaNH), consulta.IDconsulta);

                consultaNH.Texto = consulta.Texto;



                session.Update (consultaNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in ConsultaRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }
}


public int Nuevo (ConsultaEN consulta)
{
        ConsultaNH consultaNH = new ConsultaNH (consulta);

        try
        {
                SessionInitializeTransaction ();
                if (consulta.Administrador != null) {
                        // Argumento OID y no colección.
                        consultaNH
                        .Administrador = (MAETSGen.ApplicationCore.EN.MAETS.AdministradorEN)session.Load (typeof(MAETSGen.ApplicationCore.EN.MAETS.AdministradorEN), consulta.Administrador.Dni);

                        consultaNH.Administrador.Consultas
                        .Add (consultaNH);
                }
                if (consulta.Usuario != null) {
                        // Argumento OID y no colección.
                        consultaNH
                        .Usuario = (MAETSGen.ApplicationCore.EN.MAETS.UsuarioEN)session.Load (typeof(MAETSGen.ApplicationCore.EN.MAETS.UsuarioEN), consulta.Usuario.Dni);

                        consultaNH.Usuario.Consulta
                        .Add (consultaNH);
                }

                session.Save (consultaNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in ConsultaRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }

        return consultaNH.IDconsulta;
}

public void Modificar (ConsultaEN consulta)
{
        try
        {
                SessionInitializeTransaction ();
                ConsultaNH consultaNH = (ConsultaNH)session.Load (typeof(ConsultaNH), consulta.IDconsulta);

                consultaNH.Texto = consulta.Texto;

                session.Update (consultaNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in ConsultaRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }
}
public void Borrar (int IDconsulta
                    )
{
        try
        {
                SessionInitializeTransaction ();
                ConsultaNH consultaNH = (ConsultaNH)session.Load (typeof(ConsultaNH), IDconsulta);
                session.Delete (consultaNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in ConsultaRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }
}

//Sin e: LeeID
//Con e: ConsultaEN
public ConsultaEN LeeID (int IDconsulta
                         )
{
        ConsultaEN consultaEN = null;

        try
        {
                SessionInitializeTransaction ();
                consultaEN = (ConsultaEN)session.Get (typeof(ConsultaNH), IDconsulta);
                SessionCommit ();
        }

        catch (Exception) {
        }


        finally
        {
                SessionClose ();
        }

        return consultaEN;
}

public System.Collections.Generic.IList<ConsultaEN> LeeTodos (int first, int size)
{
        System.Collections.Generic.IList<ConsultaEN> result = null;
        try
        {
                SessionInitializeTransaction ();
                if (size > 0)
                        result = session.CreateCriteria (typeof(ConsultaNH)).
                                 SetFirstResult (first).SetMaxResults (size).List<ConsultaEN>();
                else
                        result = session.CreateCriteria (typeof(ConsultaNH)).List<ConsultaEN>();
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in ConsultaRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }

        return result;
}
}
}
