
using System;
using System.Text;
using MAETSGen.ApplicationCore.CEN.MAETS;
using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;
using MAETSGen.ApplicationCore.EN.MAETS;
using MAETSGen.ApplicationCore.Exceptions;
using MAETSGen.ApplicationCore.IRepository.MAETS;
using MAETSGen.ApplicationCore.CP.MAETS;
using MAETSGen.Infraestructure.EN.MAETS;


/*
 * Clase Copia:
 *
 */

namespace MAETSGen.Infraestructure.Repository.MAETS
{
public partial class CopiaRepository : BasicRepository, ICopiaRepository
{
public CopiaRepository() : base ()
{
}


public CopiaRepository(GenericSessionCP sessionAux) : base (sessionAux)
{
}


public void setSessionCP (GenericSessionCP session)
{
        sessionInside = false;
        this.session = (ISession)session.CurrentSession;
}


public CopiaEN ReadOIDDefault (int num_copia
                               )
{
        CopiaEN copiaEN = null;

        try
        {
                SessionInitializeTransaction ();
                copiaEN = (CopiaEN)session.Get (typeof(CopiaNH), num_copia);
                SessionCommit ();
        }

        catch (Exception) {
        }


        finally
        {
                SessionClose ();
        }

        return copiaEN;
}

public System.Collections.Generic.IList<CopiaEN> ReadAllDefault (int first, int size)
{
        System.Collections.Generic.IList<CopiaEN> result = null;
        try
        {
                using (ITransaction tx = session.BeginTransaction ())
                {
                        if (size > 0)
                                result = session.CreateCriteria (typeof(CopiaNH)).
                                         SetFirstResult (first).SetMaxResults (size).List<CopiaEN>();
                        else
                                result = session.CreateCriteria (typeof(CopiaNH)).List<CopiaEN>();
                }
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in CopiaRepository.", ex);
        }

        return result;
}

// Modify default (Update all attributes of the class)

public void ModifyDefault (CopiaEN copia)
{
        try
        {
                SessionInitializeTransaction ();
                CopiaNH copiaNH = (CopiaNH)session.Load (typeof(CopiaNH), copia.Num_copia);



                copiaNH.Estado = copia.Estado;

                session.Update (copiaNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in CopiaRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }
}


public int Nuevo (CopiaEN copia)
{
        CopiaNH copiaNH = new CopiaNH (copia);

        try
        {
                SessionInitializeTransaction ();
                if (copia.Biblioteca != null) {
                        // Argumento OID y no colección.
                        copiaNH
                        .Biblioteca = (MAETSGen.ApplicationCore.EN.MAETS.BibliotecaEN)session.Load (typeof(MAETSGen.ApplicationCore.EN.MAETS.BibliotecaEN), copia.Biblioteca.Id);

                        copiaNH.Biblioteca.Copia
                        .Add (copiaNH);
                }
                if (copia.Juego != null) {
                        // Argumento OID y no colección.
                        copiaNH
                        .Juego = (MAETSGen.ApplicationCore.EN.MAETS.JuegoEN)session.Load (typeof(MAETSGen.ApplicationCore.EN.MAETS.JuegoEN), copia.Juego.Nombre);

                        copiaNH.Juego.Copia
                        .Add (copiaNH);
                }

                session.Save (copiaNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in CopiaRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }

        return copiaNH.Num_copia;
}

public void Modificar (CopiaEN copia)
{
        try
        {
                SessionInitializeTransaction ();
                CopiaNH copiaNH = (CopiaNH)session.Load (typeof(CopiaNH), copia.Num_copia);

                copiaNH.Estado = copia.Estado;

                session.Update (copiaNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in CopiaRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }
}
public void Borrar (int num_copia
                    )
{
        try
        {
                SessionInitializeTransaction ();
                CopiaNH copiaNH = (CopiaNH)session.Load (typeof(CopiaNH), num_copia);
                session.Delete (copiaNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in CopiaRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }
}

//Sin e: LeeID
//Con e: CopiaEN
public CopiaEN LeeID (int num_copia
                      )
{
        CopiaEN copiaEN = null;

        try
        {
                SessionInitializeTransaction ();
                copiaEN = (CopiaEN)session.Get (typeof(CopiaNH), num_copia);
                SessionCommit ();
        }

        catch (Exception) {
        }


        finally
        {
                SessionClose ();
        }

        return copiaEN;
}

public System.Collections.Generic.IList<CopiaEN> LeeTodos (int first, int size)
{
        System.Collections.Generic.IList<CopiaEN> result = null;
        try
        {
                SessionInitializeTransaction ();
                if (size > 0)
                        result = session.CreateCriteria (typeof(CopiaNH)).
                                 SetFirstResult (first).SetMaxResults (size).List<CopiaEN>();
                else
                        result = session.CreateCriteria (typeof(CopiaNH)).List<CopiaEN>();
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in CopiaRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }

        return result;
}

public System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.CopiaEN> DameCopias (string n_game)
{
        System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.CopiaEN> result;
        try
        {
                SessionInitializeTransaction ();
                //String sql = @"FROM CopiaNH self where select cop FROM CopiaNH as cop where cop.Juego.Nombre =:n_game";
                //IQuery query = session.CreateQuery(sql);
                IQuery query = (IQuery)session.GetNamedQuery ("CopiaNHDameCopiasHQL");
                query.SetParameter ("n_game", n_game);

                result = query.List<MAETSGen.ApplicationCore.EN.MAETS.CopiaEN>();
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in CopiaRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }

        return result;
}
public System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.CopiaEN> DameEstadoJuego (MAETSGen.ApplicationCore.Enumerated.MAETS.Estado_juegoEnum ? estad)
{
        System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.CopiaEN> result;
        try
        {
                SessionInitializeTransaction ();
                //String sql = @"FROM CopiaNH self where select cop FROM CopiaNH as cop where cop.Estado =:estad";
                //IQuery query = session.CreateQuery(sql);
                IQuery query = (IQuery)session.GetNamedQuery ("CopiaNHdameEstadoJuegoHQL");
                query.SetParameter ("estad", estad);

                result = query.List<MAETSGen.ApplicationCore.EN.MAETS.CopiaEN>();
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in CopiaRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }

        return result;
}
}
}
