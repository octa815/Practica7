
using System;
using System.Text;
using MAETSGen.ApplicationCore.CEN.MAETS;
using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;
using MAETSGen.ApplicationCore.EN.MAETS;
using MAETSGen.ApplicationCore.Exceptions;
using MAETSGen.ApplicationCore.IRepository.MAETS;
using MAETSGen.ApplicationCore.CP.MAETS;
using MAETSGen.Infraestructure.EN.MAETS;


/*
 * Clase Distribuidora:
 *
 */

namespace MAETSGen.Infraestructure.Repository.MAETS
{
public partial class DistribuidoraRepository : BasicRepository, IDistribuidoraRepository
{
public DistribuidoraRepository() : base ()
{
}


public DistribuidoraRepository(GenericSessionCP sessionAux) : base (sessionAux)
{
}


public void setSessionCP (GenericSessionCP session)
{
        sessionInside = false;
        this.session = (ISession)session.CurrentSession;
}


public DistribuidoraEN ReadOIDDefault (int ID_distrib
                                       )
{
        DistribuidoraEN distribuidoraEN = null;

        try
        {
                SessionInitializeTransaction ();
                distribuidoraEN = (DistribuidoraEN)session.Get (typeof(DistribuidoraNH), ID_distrib);
                SessionCommit ();
        }

        catch (Exception) {
        }


        finally
        {
                SessionClose ();
        }

        return distribuidoraEN;
}

public System.Collections.Generic.IList<DistribuidoraEN> ReadAllDefault (int first, int size)
{
        System.Collections.Generic.IList<DistribuidoraEN> result = null;
        try
        {
                using (ITransaction tx = session.BeginTransaction ())
                {
                        if (size > 0)
                                result = session.CreateCriteria (typeof(DistribuidoraNH)).
                                         SetFirstResult (first).SetMaxResults (size).List<DistribuidoraEN>();
                        else
                                result = session.CreateCriteria (typeof(DistribuidoraNH)).List<DistribuidoraEN>();
                }
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in DistribuidoraRepository.", ex);
        }

        return result;
}

// Modify default (Update all attributes of the class)

public void ModifyDefault (DistribuidoraEN distribuidora)
{
        try
        {
                SessionInitializeTransaction ();
                DistribuidoraNH distribuidoraNH = (DistribuidoraNH)session.Load (typeof(DistribuidoraNH), distribuidora.ID_distrib);

                distribuidoraNH.Nombre = distribuidora.Nombre;


                session.Update (distribuidoraNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in DistribuidoraRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }
}


public int Nuevo (DistribuidoraEN distribuidora)
{
        DistribuidoraNH distribuidoraNH = new DistribuidoraNH (distribuidora);

        try
        {
                SessionInitializeTransaction ();

                session.Save (distribuidoraNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in DistribuidoraRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }

        return distribuidoraNH.ID_distrib;
}

public void Modificar (DistribuidoraEN distribuidora)
{
        try
        {
                SessionInitializeTransaction ();
                DistribuidoraNH distribuidoraNH = (DistribuidoraNH)session.Load (typeof(DistribuidoraNH), distribuidora.ID_distrib);

                distribuidoraNH.Nombre = distribuidora.Nombre;

                session.Update (distribuidoraNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in DistribuidoraRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }
}
public void Borrar (int ID_distrib
                    )
{
        try
        {
                SessionInitializeTransaction ();
                DistribuidoraNH distribuidoraNH = (DistribuidoraNH)session.Load (typeof(DistribuidoraNH), ID_distrib);
                session.Delete (distribuidoraNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in DistribuidoraRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }
}
}
}
