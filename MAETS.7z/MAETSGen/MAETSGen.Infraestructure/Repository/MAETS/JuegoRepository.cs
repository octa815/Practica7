
using System;
using System.Text;
using MAETSGen.ApplicationCore.CEN.MAETS;
using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;
using MAETSGen.ApplicationCore.EN.MAETS;
using MAETSGen.ApplicationCore.Exceptions;
using MAETSGen.ApplicationCore.IRepository.MAETS;
using MAETSGen.ApplicationCore.CP.MAETS;
using MAETSGen.Infraestructure.EN.MAETS;


/*
 * Clase Juego:
 *
 */

namespace MAETSGen.Infraestructure.Repository.MAETS
{
public partial class JuegoRepository : BasicRepository, IJuegoRepository
{
public JuegoRepository() : base ()
{
}


public JuegoRepository(GenericSessionCP sessionAux) : base (sessionAux)
{
}


public void setSessionCP (GenericSessionCP session)
{
        sessionInside = false;
        this.session = (ISession)session.CurrentSession;
}


public JuegoEN ReadOIDDefault (string nombre
                               )
{
        JuegoEN juegoEN = null;

        try
        {
                SessionInitializeTransaction ();
                juegoEN = (JuegoEN)session.Get (typeof(JuegoNH), nombre);
                SessionCommit ();
        }

        catch (Exception) {
        }


        finally
        {
                SessionClose ();
        }

        return juegoEN;
}

public System.Collections.Generic.IList<JuegoEN> ReadAllDefault (int first, int size)
{
        System.Collections.Generic.IList<JuegoEN> result = null;
        try
        {
                using (ITransaction tx = session.BeginTransaction ())
                {
                        if (size > 0)
                                result = session.CreateCriteria (typeof(JuegoNH)).
                                         SetFirstResult (first).SetMaxResults (size).List<JuegoEN>();
                        else
                                result = session.CreateCriteria (typeof(JuegoNH)).List<JuegoEN>();
                }
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in JuegoRepository.", ex);
        }

        return result;
}

// Modify default (Update all attributes of the class)

public void ModifyDefault (JuegoEN juego)
{
        try
        {
                SessionInitializeTransaction ();
                JuegoNH juegoNH = (JuegoNH)session.Load (typeof(JuegoNH), juego.Nombre);

                juegoNH.Feche_Lanz = juego.Feche_Lanz;


                juegoNH.Precio = juego.Precio;


                juegoNH.Horas = juego.Horas;


                juegoNH.Requisitos = juego.Requisitos;







                session.Update (juegoNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in JuegoRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }
}


public string Nuevo (JuegoEN juego)
{
        JuegoNH juegoNH = new JuegoNH (juego);

        try
        {
                SessionInitializeTransaction ();
                if (juego.MAETS != null) {
                        // Argumento OID y no colección.
                        juegoNH
                        .MAETS = (MAETSGen.ApplicationCore.EN.MAETS.MAETSEN)session.Load (typeof(MAETSGen.ApplicationCore.EN.MAETS.MAETSEN), juego.MAETS.Id);

                        juegoNH.MAETS.Juegos
                        .Add (juegoNH);
                }
                if (juego.Categorias != null) {
                        // Argumento OID y no colección.
                        juegoNH
                        .Categorias = (MAETSGen.ApplicationCore.EN.MAETS.CategoriasEN)session.Load (typeof(MAETSGen.ApplicationCore.EN.MAETS.CategoriasEN), juego.Categorias.Cat);

                        juegoNH.Categorias.Juego
                        .Add (juegoNH);
                }
                if (juego.Distribuidora != null) {
                        // Argumento OID y no colección.
                        juegoNH
                        .Distribuidora = (MAETSGen.ApplicationCore.EN.MAETS.DistribuidoraEN)session.Load (typeof(MAETSGen.ApplicationCore.EN.MAETS.DistribuidoraEN), juego.Distribuidora.ID_distrib);

                        juegoNH.Distribuidora.Juego
                        .Add (juegoNH);
                }

                session.Save (juegoNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in JuegoRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }

        return juegoNH.Nombre;
}

public void Modificar (JuegoEN juego)
{
        try
        {
                SessionInitializeTransaction ();
                JuegoNH juegoNH = (JuegoNH)session.Load (typeof(JuegoNH), juego.Nombre);

                juegoNH.Feche_Lanz = juego.Feche_Lanz;


                juegoNH.Precio = juego.Precio;


                juegoNH.Horas = juego.Horas;


                juegoNH.Requisitos = juego.Requisitos;

                session.Update (juegoNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in JuegoRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }
}
public void Borrar (string nombre
                    )
{
        try
        {
                SessionInitializeTransaction ();
                JuegoNH juegoNH = (JuegoNH)session.Load (typeof(JuegoNH), nombre);
                session.Delete (juegoNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in JuegoRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }
}

//Sin e: LeeID
//Con e: JuegoEN
public JuegoEN LeeID (string nombre
                      )
{
        JuegoEN juegoEN = null;

        try
        {
                SessionInitializeTransaction ();
                juegoEN = (JuegoEN)session.Get (typeof(JuegoNH), nombre);
                SessionCommit ();
        }

        catch (Exception) {
        }


        finally
        {
                SessionClose ();
        }

        return juegoEN;
}

public System.Collections.Generic.IList<JuegoEN> LeeTodos (int first, int size)
{
        System.Collections.Generic.IList<JuegoEN> result = null;
        try
        {
                SessionInitializeTransaction ();
                if (size > 0)
                        result = session.CreateCriteria (typeof(JuegoNH)).
                                 SetFirstResult (first).SetMaxResults (size).List<JuegoEN>();
                else
                        result = session.CreateCriteria (typeof(JuegoNH)).List<JuegoEN>();
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in JuegoRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }

        return result;
}

public System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.JuegoEN> DameJuegoporCat (string cat_game)
{
        System.Collections.Generic.IList<MAETSGen.ApplicationCore.EN.MAETS.JuegoEN> result;
        try
        {
                SessionInitializeTransaction ();
                //String sql = @"FROM JuegoNH self where select game FROM JuegoNH as game where game.Categorias.Cat =:cat_game";
                //IQuery query = session.CreateQuery(sql);
                IQuery query = (IQuery)session.GetNamedQuery ("JuegoNHdameJuegoporCatHQL");
                query.SetParameter ("cat_game", cat_game);

                result = query.List<MAETSGen.ApplicationCore.EN.MAETS.JuegoEN>();
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in JuegoRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }

        return result;
}
}
}
