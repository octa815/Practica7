
using System;
using System.Text;
using MAETSGen.ApplicationCore.CEN.MAETS;
using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;
using MAETSGen.ApplicationCore.EN.MAETS;
using MAETSGen.ApplicationCore.Exceptions;
using MAETSGen.ApplicationCore.IRepository.MAETS;
using MAETSGen.ApplicationCore.CP.MAETS;
using MAETSGen.Infraestructure.EN.MAETS;


/*
 * Clase LineaCesta:
 *
 */

namespace MAETSGen.Infraestructure.Repository.MAETS
{
public partial class LineaCestaRepository : BasicRepository, ILineaCestaRepository
{
public LineaCestaRepository() : base ()
{
}


public LineaCestaRepository(GenericSessionCP sessionAux) : base (sessionAux)
{
}


public void setSessionCP (GenericSessionCP session)
{
        sessionInside = false;
        this.session = (ISession)session.CurrentSession;
}


public LineaCestaEN ReadOIDDefault (int id
                                    )
{
        LineaCestaEN lineaCestaEN = null;

        try
        {
                SessionInitializeTransaction ();
                lineaCestaEN = (LineaCestaEN)session.Get (typeof(LineaCestaNH), id);
                SessionCommit ();
        }

        catch (Exception) {
        }


        finally
        {
                SessionClose ();
        }

        return lineaCestaEN;
}

public System.Collections.Generic.IList<LineaCestaEN> ReadAllDefault (int first, int size)
{
        System.Collections.Generic.IList<LineaCestaEN> result = null;
        try
        {
                using (ITransaction tx = session.BeginTransaction ())
                {
                        if (size > 0)
                                result = session.CreateCriteria (typeof(LineaCestaNH)).
                                         SetFirstResult (first).SetMaxResults (size).List<LineaCestaEN>();
                        else
                                result = session.CreateCriteria (typeof(LineaCestaNH)).List<LineaCestaEN>();
                }
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in LineaCestaRepository.", ex);
        }

        return result;
}

// Modify default (Update all attributes of the class)

public void ModifyDefault (LineaCestaEN lineaCesta)
{
        try
        {
                SessionInitializeTransaction ();
                LineaCestaNH lineaCestaNH = (LineaCestaNH)session.Load (typeof(LineaCestaNH), lineaCesta.Id);


                session.Update (lineaCestaNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in LineaCestaRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }
}


public int Nuevo (LineaCestaEN lineaCesta)
{
        LineaCestaNH lineaCestaNH = new LineaCestaNH (lineaCesta);

        try
        {
                SessionInitializeTransaction ();
                if (lineaCesta.Cesta != null) {
                        // Argumento OID y no colección.
                        lineaCestaNH
                        .Cesta = (MAETSGen.ApplicationCore.EN.MAETS.CestaEN)session.Load (typeof(MAETSGen.ApplicationCore.EN.MAETS.CestaEN), lineaCesta.Cesta.Id_pedido);

                        lineaCestaNH.Cesta.LineasCesta
                        .Add (lineaCestaNH);
                }
                if (lineaCesta.Juego != null) {
                        // Argumento OID y no colección.
                        lineaCestaNH
                        .Juego = (MAETSGen.ApplicationCore.EN.MAETS.JuegoEN)session.Load (typeof(MAETSGen.ApplicationCore.EN.MAETS.JuegoEN), lineaCesta.Juego.Nombre);

                        lineaCestaNH.Juego.LineaCesta
                        .Add (lineaCestaNH);
                }

                session.Save (lineaCestaNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in LineaCestaRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }

        return lineaCestaNH.Id;
}

public void Modificar (LineaCestaEN lineaCesta)
{
        try
        {
                SessionInitializeTransaction ();
                LineaCestaNH lineaCestaNH = (LineaCestaNH)session.Load (typeof(LineaCestaNH), lineaCesta.Id);
                session.Update (lineaCestaNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in LineaCestaRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }
}
public void Borrar (int id
                    )
{
        try
        {
                SessionInitializeTransaction ();
                LineaCestaNH lineaCestaNH = (LineaCestaNH)session.Load (typeof(LineaCestaNH), id);
                session.Delete (lineaCestaNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in LineaCestaRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }
}
}
}
