
using System;
using System.Text;
using MAETSGen.ApplicationCore.CEN.MAETS;
using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;
using MAETSGen.ApplicationCore.EN.MAETS;
using MAETSGen.ApplicationCore.Exceptions;
using MAETSGen.ApplicationCore.IRepository.MAETS;
using MAETSGen.ApplicationCore.CP.MAETS;
using MAETSGen.Infraestructure.EN.MAETS;


/*
 * Clase Logro:
 *
 */

namespace MAETSGen.Infraestructure.Repository.MAETS
{
public partial class LogroRepository : BasicRepository, ILogroRepository
{
public LogroRepository() : base ()
{
}


public LogroRepository(GenericSessionCP sessionAux) : base (sessionAux)
{
}


public void setSessionCP (GenericSessionCP session)
{
        sessionInside = false;
        this.session = (ISession)session.CurrentSession;
}


public LogroEN ReadOIDDefault (int id
                               )
{
        LogroEN logroEN = null;

        try
        {
                SessionInitializeTransaction ();
                logroEN = (LogroEN)session.Get (typeof(LogroNH), id);
                SessionCommit ();
        }

        catch (Exception) {
        }


        finally
        {
                SessionClose ();
        }

        return logroEN;
}

public System.Collections.Generic.IList<LogroEN> ReadAllDefault (int first, int size)
{
        System.Collections.Generic.IList<LogroEN> result = null;
        try
        {
                using (ITransaction tx = session.BeginTransaction ())
                {
                        if (size > 0)
                                result = session.CreateCriteria (typeof(LogroNH)).
                                         SetFirstResult (first).SetMaxResults (size).List<LogroEN>();
                        else
                                result = session.CreateCriteria (typeof(LogroNH)).List<LogroEN>();
                }
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in LogroRepository.", ex);
        }

        return result;
}

// Modify default (Update all attributes of the class)

public void ModifyDefault (LogroEN logro)
{
        try
        {
                SessionInitializeTransaction ();
                LogroNH logroNH = (LogroNH)session.Load (typeof(LogroNH), logro.Id);


                logroNH.Nombre = logro.Nombre;


                logroNH.Descrip = logro.Descrip;

                session.Update (logroNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in LogroRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }
}


public int Nuevo (LogroEN logro)
{
        LogroNH logroNH = new LogroNH (logro);

        try
        {
                SessionInitializeTransaction ();

                session.Save (logroNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in LogroRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }

        return logroNH.Id;
}

public void Modificar (LogroEN logro)
{
        try
        {
                SessionInitializeTransaction ();
                LogroNH logroNH = (LogroNH)session.Load (typeof(LogroNH), logro.Id);

                logroNH.Nombre = logro.Nombre;


                logroNH.Descrip = logro.Descrip;

                session.Update (logroNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in LogroRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }
}
public void Borrar (int id
                    )
{
        try
        {
                SessionInitializeTransaction ();
                LogroNH logroNH = (LogroNH)session.Load (typeof(LogroNH), id);
                session.Delete (logroNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in LogroRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }
}

//Sin e: LeeID
//Con e: LogroEN
public LogroEN LeeID (int id
                      )
{
        LogroEN logroEN = null;

        try
        {
                SessionInitializeTransaction ();
                logroEN = (LogroEN)session.Get (typeof(LogroNH), id);
                SessionCommit ();
        }

        catch (Exception) {
        }


        finally
        {
                SessionClose ();
        }

        return logroEN;
}

public System.Collections.Generic.IList<LogroEN> LeeTodos (int first, int size)
{
        System.Collections.Generic.IList<LogroEN> result = null;
        try
        {
                SessionInitializeTransaction ();
                if (size > 0)
                        result = session.CreateCriteria (typeof(LogroNH)).
                                 SetFirstResult (first).SetMaxResults (size).List<LogroEN>();
                else
                        result = session.CreateCriteria (typeof(LogroNH)).List<LogroEN>();
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in LogroRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }

        return result;
}
}
}
