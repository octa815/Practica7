
using System;
using System.Text;
using MAETSGen.ApplicationCore.CEN.MAETS;
using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;
using MAETSGen.ApplicationCore.EN.MAETS;
using MAETSGen.ApplicationCore.Exceptions;
using MAETSGen.ApplicationCore.IRepository.MAETS;
using MAETSGen.ApplicationCore.CP.MAETS;
using MAETSGen.Infraestructure.EN.MAETS;


/*
 * Clase MAETS:
 *
 */

namespace MAETSGen.Infraestructure.Repository.MAETS
{
public partial class MAETSRepository : BasicRepository, IMAETSRepository
{
public MAETSRepository() : base ()
{
}


public MAETSRepository(GenericSessionCP sessionAux) : base (sessionAux)
{
}


public void setSessionCP (GenericSessionCP session)
{
        sessionInside = false;
        this.session = (ISession)session.CurrentSession;
}


public MAETSEN ReadOIDDefault (int id
                               )
{
        MAETSEN mAETSEN = null;

        try
        {
                SessionInitializeTransaction ();
                mAETSEN = (MAETSEN)session.Get (typeof(MAETSNH), id);
                SessionCommit ();
        }

        catch (Exception) {
        }


        finally
        {
                SessionClose ();
        }

        return mAETSEN;
}

public System.Collections.Generic.IList<MAETSEN> ReadAllDefault (int first, int size)
{
        System.Collections.Generic.IList<MAETSEN> result = null;
        try
        {
                using (ITransaction tx = session.BeginTransaction ())
                {
                        if (size > 0)
                                result = session.CreateCriteria (typeof(MAETSNH)).
                                         SetFirstResult (first).SetMaxResults (size).List<MAETSEN>();
                        else
                                result = session.CreateCriteria (typeof(MAETSNH)).List<MAETSEN>();
                }
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in MAETSRepository.", ex);
        }

        return result;
}

// Modify default (Update all attributes of the class)

public void ModifyDefault (MAETSEN mAETS)
{
        try
        {
                SessionInitializeTransaction ();
                MAETSNH mAETSNH = (MAETSNH)session.Load (typeof(MAETSNH), mAETS.Id);

                session.Update (mAETSNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in MAETSRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }
}


public int Nuevo (MAETSEN mAETS)
{
        MAETSNH mAETSNH = new MAETSNH (mAETS);

        try
        {
                SessionInitializeTransaction ();

                session.Save (mAETSNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in MAETSRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }

        return mAETSNH.Id;
}

public void Modificar (MAETSEN mAETS)
{
        try
        {
                SessionInitializeTransaction ();
                MAETSNH mAETSNH = (MAETSNH)session.Load (typeof(MAETSNH), mAETS.Id);
                session.Update (mAETSNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in MAETSRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }
}
public void Borrar (int id
                    )
{
        try
        {
                SessionInitializeTransaction ();
                MAETSNH mAETSNH = (MAETSNH)session.Load (typeof(MAETSNH), id);
                session.Delete (mAETSNH);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is MAETSGen.ApplicationCore.Exceptions.ModelException)
                        throw;
                else throw new MAETSGen.ApplicationCore.Exceptions.DataLayerException ("Error in MAETSRepository.", ex);
        }


        finally
        {
                SessionClose ();
        }
}
}
}
