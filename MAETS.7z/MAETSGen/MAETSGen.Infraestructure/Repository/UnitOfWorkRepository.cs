

using MAETSGen.ApplicationCore.IRepository.MAETS;
using MAETSGen.Infraestructure.Repository.MAETS;
using MAETSGen.Infraestructure.CP;
using System;
using System.Collections.Generic;
using System.Text;

namespace MAETSGen.Infraestructure.Repository
{
public class UnitOfWorkRepository : GenericUnitOfWorkRepository
{
SessionCPNHibernate session;


public UnitOfWorkRepository(SessionCPNHibernate session)
{
        this.session = session;
}

public override IClienteRepository ClienteRepository {
        get
        {
                this.clienterepository = new ClienteRepository ();
                this.clienterepository.setSessionCP (session);
                return this.clienterepository;
        }
}

public override IAdministradorRepository AdministradorRepository {
        get
        {
                this.administradorrepository = new AdministradorRepository ();
                this.administradorrepository.setSessionCP (session);
                return this.administradorrepository;
        }
}

public override IJuegoRepository JuegoRepository {
        get
        {
                this.juegorepository = new JuegoRepository ();
                this.juegorepository.setSessionCP (session);
                return this.juegorepository;
        }
}

public override ICestaRepository CestaRepository {
        get
        {
                this.cestarepository = new CestaRepository ();
                this.cestarepository.setSessionCP (session);
                return this.cestarepository;
        }
}

public override IBibliotecaRepository BibliotecaRepository {
        get
        {
                this.bibliotecarepository = new BibliotecaRepository ();
                this.bibliotecarepository.setSessionCP (session);
                return this.bibliotecarepository;
        }
}

public override ILogroRepository LogroRepository {
        get
        {
                this.logrorepository = new LogroRepository ();
                this.logrorepository.setSessionCP (session);
                return this.logrorepository;
        }
}

public override ILineaCestaRepository LineaCestaRepository {
        get
        {
                this.lineacestarepository = new LineaCestaRepository ();
                this.lineacestarepository.setSessionCP (session);
                return this.lineacestarepository;
        }
}

public override IMAETSRepository MAETSRepository {
        get
        {
                this.maetsrepository = new MAETSRepository ();
                this.maetsrepository.setSessionCP (session);
                return this.maetsrepository;
        }
}

public override IConsultaRepository ConsultaRepository {
        get
        {
                this.consultarepository = new ConsultaRepository ();
                this.consultarepository.setSessionCP (session);
                return this.consultarepository;
        }
}

public override IComentariosRepository ComentariosRepository {
        get
        {
                this.comentariosrepository = new ComentariosRepository ();
                this.comentariosrepository.setSessionCP (session);
                return this.comentariosrepository;
        }
}

public override ICategoriasRepository CategoriasRepository {
        get
        {
                this.categoriasrepository = new CategoriasRepository ();
                this.categoriasrepository.setSessionCP (session);
                return this.categoriasrepository;
        }
}

public override IUsuarioRepository UsuarioRepository {
        get
        {
                this.usuariorepository = new UsuarioRepository ();
                this.usuariorepository.setSessionCP (session);
                return this.usuariorepository;
        }
}

public override IDistribuidoraRepository DistribuidoraRepository {
        get
        {
                this.distribuidorarepository = new DistribuidoraRepository ();
                this.distribuidorarepository.setSessionCP (session);
                return this.distribuidorarepository;
        }
}

public override ICopiaRepository CopiaRepository {
        get
        {
                this.copiarepository = new CopiaRepository ();
                this.copiarepository.setSessionCP (session);
                return this.copiarepository;
        }
}
}
}

